# UDAAN Safeguarding Security Specification (Phase 0)

## 1. Data Invariants
1. **Strict Ownership & Role Integrity**: Users cannot self-assign `role: 'staff'` or `role: 'admin'` on `/users/{userId}` or create unauthorized entries in `/school_staff/{staffId}` or `/admins/{adminId}`. Only verified platform admins (`isAdmin()`) may grant staff/admin permissions.
2. **Child Report Privacy Isolation**: A student (`reporterUid`) can create a report only under their own `request.auth.uid` and read only their own reports. A student cannot read, list, update, or delete another student's report.
3. **Parent Safeguarding Gate**: A verified parent (`parentUid == request.auth.uid`) can read/list a report ONLY when `parentSafeToNotify == true`. If the child indicated that notifying a parent could put them at risk (`parentSafeToNotify == false`, routed solely to `school_counselor`), the parent is blocked from reading that report.
4. **School Staff Authorization Boundary**: Only verified, authorized `school_staff` for the matching `schoolId` (or `isAdmin()`) may read full reports, update case statuses, or write `/follow_ups`.
5. **Temporal Integrity & Terminal State Locking**: Every `create` requires `createdAt == request.time`, and every `update` requires `updatedAt == request.time` while preserving immutable fields (`createdAt`, `reporterUid`, `parentUid`, `studentUid`). Once a report reaches `status == 'resolved'`, non-admin edits are rejected.
6. **Bounded Arrays & Anti-Ghost Field Enforcement**: Every `create` enforces exact key sets (`hasAll` + `hasOnly`), string `.size()` bounds, regex-checked IDs (`^[a-zA-Z0-9_\\-]+$`), and list bounds (`size() <= 10` for selections, `size() <= 20` for `staffAccessUids`).

## 2. The "Dirty Dozen" Adversarial Payloads (Must Return PERMISSION_DENIED)
1. **Self-Assigned Admin Role on User Create**: Creating `/users/attacker` with `{ role: 'admin', ... }` -> Denied because `users` creation restricts `role` to `'student'` or `'parent'` unless `isAdmin()`.
2. **Ghost Field Shadow Write on Report**: Creating `/reports/rep1` with an extra `{ isVerifiedByAdmin: true }` field -> Denied by `data.keys().hasOnly(...)`.
3. **UID Spoofing on Report Create**: Creating `/reports/rep2` with `reporterUid: 'victim_uid'` when `request.auth.uid == 'attacker_uid'` -> Denied by `data.reporterUid == request.auth.uid`.
4. **Unverified Email Bypass**: Attempting any write with `request.auth.token.email_verified == false` -> Denied by `isVerifiedUser()`.
5. **Cross-Student Report Read**: Student A calling `get` or `list` on `/reports` where `reporterUid == 'student_B'` -> Denied by `allow get`/`allow list` ownership checks.
6. **Parent Reading Unsafe-to-Notify Report**: Parent reading `/reports/rep3` where `parentUid == parent_uid` but `parentSafeToNotify == false` -> Denied by `parentSafeToNotify == true` gate.
7. **ID Poisoning (>128 chars or invalid chars)**: Creating `/reports/invalid$id_too_long...` -> Denied by `isValidId(reportId)`.
8. **Payload Size Exhaustion**: Submitting `additionalInfo` with 5,000 characters (limit 2000) -> Denied by `data.additionalInfo.size() <= 2000`.
9. **Client Timestamp Forgery**: Creating a report with `createdAt: '2020-01-01T00:00:00Z'` instead of `serverTimestamp()` -> Denied by `data.createdAt == request.time`.
10. **Student Tampering with Status/AI Summary**: Reporter updating `status: 'resolved'` or overwriting `aiSummary` after submission -> Denied because report updates are restricted to authorized school staff/admin.
11. **Orphan Follow-Up Creation**: Creating `/follow_ups/fu1` with a non-existent `reportId` -> Denied by `exists(/databases/$(database)/documents/reports/$(incoming().reportId))`.
12. **Terminal State Overwrite**: Non-admin staff attempting to mutate a report whose existing `status == 'resolved'` -> Denied by terminal state locking.
