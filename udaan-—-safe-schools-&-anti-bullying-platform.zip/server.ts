import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import nodemailer from 'nodemailer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

interface ReportAnalyzePayload {
  referenceCode: string;
  incidents: string[];
  frequency: string;
  locations: string[];
  feelings: string[];
  isSafeRightNow: 'yes' | 'no' | 'unsure';
  additionalInfo?: string;
}

interface NotificationDispatchPayload {
  referenceCode: string;
  recipientEmail: string;
  recipientEmailVerified: boolean;
  recipientName: string;
  parentSafeToNotify: boolean;
  trustedAdultChannel: 'parent' | 'school_counselor' | 'both';
  urgentFlag: boolean;
  notifyOnSubmit: boolean;
  notifyUrgentOnly: boolean;
  aiSummary: {
    incidentCategory: string;
    reportedFactsSummary: string;
    frequency: string;
    reportedLocation: string;
    emotionalImpact: string;
    immediateSafetyConcern: boolean;
    recommendedNextSteps: string;
    disclaimer: string;
  };
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in server environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function isSmtpConfigured(): boolean {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

function isValidEmail(email: string): boolean {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

async function createApp() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Health & integration readiness endpoint (never exposes secrets)
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
      smtpConfigured: isSmtpConfigured(),
      appUrlConfigured: Boolean(process.env.APP_URL),
    });
  });

  // Server-side Gemini AI structured report generation
  app.post('/api/reports/analyze', async (req: Request, res: Response) => {
    try {
      const body = req.body as Partial<ReportAnalyzePayload>;
      if (
        !Array.isArray(body.incidents) ||
        body.incidents.length === 0 ||
        typeof body.frequency !== 'string' ||
        !Array.isArray(body.locations) ||
        body.locations.length === 0 ||
        !Array.isArray(body.feelings) ||
        body.feelings.length === 0 ||
        (body.isSafeRightNow !== 'yes' &&
          body.isSafeRightNow !== 'no' &&
          body.isSafeRightNow !== 'unsure')
      ) {
        res.status(400).json({
          error: 'Invalid questionnaire payload. Required selections are missing.',
        });
        return;
      }

      const safeAdditionalInfo =
        typeof body.additionalInfo === 'string'
          ? body.additionalInfo.trim().slice(0, 2000)
          : '';

      const ai = getGeminiClient();

      const promptText = [
        `Reference Code: ${body.referenceCode || 'UDAAN-REPORT'}`,
        `Reported Incidents: ${body.incidents.join('; ')}`,
        `Reported Frequency: ${body.frequency}`,
        `Reported Locations: ${body.locations.join('; ')}`,
        `Emotions Expressed by Student: ${body.feelings.join('; ')}`,
        `Student Response to "Are you safe right now?": ${body.isSafeRightNow}`,
        `Optional Student Note: ${safeAdditionalInfo ? safeAdditionalInfo : 'None provided'}`,
      ].join('\n');

      const systemInstruction = [
        'You are a child-safeguarding report summarization assistant for UDAAN.',
        'Generate a clear, factual, empathetic, structured safeguarding summary strictly from the student questionnaire responses.',
        'MANDATORY SAFEGUARDING & AI SAFETY RULES:',
        '1. NEVER invent information, names, motives, or events not explicitly stated in the questionnaire.',
        '2. NEVER alter the meaning of the child’s answers. Use neutral, factual attribution such as "A student has reported..." and "These incidents reportedly occur...".',
        '3. NEVER diagnose a child medically, psychologically, or behaviorally.',
        '4. NEVER determine whether an allegation is true or false.',
        '5. NEVER automatically label another student as a bully.',
        '6. NEVER make or recommend disciplinary decisions or punishments.',
        '7. Clearly distinguish reported facts (in reportedFactsSummary) from supportive next-step guidance for the trusted adult (in recommendedNextSteps).',
        '8. Set immediateSafetyConcern to true if "Are you safe right now?" is "no" or "unsure", OR if threats/physical harm indicate urgent risk.',
        '9. Keep reportedFactsSummary concise (2-4 sentences) and empathetic, suitable for a parent or school safeguarding counselor.',
        '10. Keep recommendedNextSteps focused on calm listening without judgement, checking immediate physical/emotional safety, and coordinating with the school safeguarding lead.',
      ].join('\n');

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: promptText,
        config: {
          systemInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              incidentCategory: {
                type: Type.STRING,
                description:
                  'Concise factual category summarizing reported incident types (e.g., Verbal & Social Exclusion, Physical & Verbal Incidents, Online Bullying).',
              },
              reportedFactsSummary: {
                type: Type.STRING,
                description:
                  '2-4 factual sentences summarizing what the student reported, where, how often, and emotions expressed, without inventing facts or diagnosing.',
              },
              frequency: {
                type: Type.STRING,
                description: 'Exact reported frequency from the questionnaire.',
              },
              reportedLocation: {
                type: Type.STRING,
                description: 'Comma-separated reported locations.',
              },
              emotionalImpact: {
                type: Type.STRING,
                description: 'Summary of the emotions the student reported feeling.',
              },
              immediateSafetyConcern: {
                type: Type.BOOLEAN,
                description:
                  'True if the student answered no or unsure to immediate safety, or reported threats/physical harm requiring urgent human check-in.',
              },
              recommendedNextSteps: {
                type: Type.STRING,
                description:
                  'Supportive, non-disciplinary guidance for the trusted adult (listen privately without judgement, ensure immediate safety, coordinate with school safeguarding staff).',
              },
              disclaimer: {
                type: Type.STRING,
                description:
                  'One-sentence notice clearly separating reported facts from AI-assisted guidance and reminding that human safeguarding review is required.',
              },
            },
            required: [
              'incidentCategory',
              'reportedFactsSummary',
              'frequency',
              'reportedLocation',
              'emotionalImpact',
              'immediateSafetyConcern',
              'recommendedNextSteps',
              'disclaimer',
            ],
          },
        },
      });

      const rawText = response.text;
      if (!rawText) {
        throw new Error('Gemini API returned an empty summary response.');
      }

      const parsed = JSON.parse(rawText);
      // Enforce deterministic safety rule: never let model under-flag explicit "no" or "unsure"
      if (body.isSafeRightNow === 'no' || body.isSafeRightNow === 'unsure') {
        parsed.immediateSafetyConcern = true;
      }

      res.json({ aiSummary: parsed });
    } catch (err: unknown) {
      let message =
        err instanceof Error ? err.message : 'Failed to generate safeguarding summary.';
      // Unwrap structured JSON error messages from GoogleGenAI SDK when present
      try {
        const outer = JSON.parse(message);
        const innerMsg = outer?.error?.message || outer?.message;
        if (typeof innerMsg === 'string' && innerMsg.trim()) {
          message = innerMsg;
        }
      } catch {
        // Keep original message if not JSON
      }
      console.error('Gemini analyze error:', message);
      res.status(502).json({ error: message });
    }
  });

  // Server-side safeguarded parent/trusted adult email notification endpoint
  app.post('/api/notifications/dispatch', async (req: Request, res: Response) => {
    try {
      const body = req.body as Partial<NotificationDispatchPayload>;
      if (!body.referenceCode || !body.aiSummary) {
        res.status(400).json({ error: 'Missing report referenceCode or aiSummary.' });
        return;
      }

      // Safeguarding Rule 1: Child safety override (never email parent if child indicated risk)
      if (!body.parentSafeToNotify || body.trustedAdultChannel === 'school_counselor') {
        res.json({
          deliveryStatus: 'suppressed_child_safety',
          safeguardingCheckPassed: false,
          smtpConfigured: isSmtpConfigured(),
          subject: 'Safeguarding Routing: School Counselor Only',
          summaryPreview:
            'Parent email notification was intentionally suppressed in accordance with child safety routing. Only authorized school safeguarding personnel can review this report.',
          reason:
            'Child selected the school counselor safe-adult pathway to avoid potential risk at home.',
        });
        return;
      }

      // Safeguarding Rule 2: Never send sensitive reports to unverified or invalid email addresses
      if (!body.recipientEmailVerified || !isValidEmail(body.recipientEmail || '')) {
        res.json({
          deliveryStatus: 'blocked_unverified_email',
          safeguardingCheckPassed: false,
          smtpConfigured: isSmtpConfigured(),
          subject: 'Important – Your Child May Need Your Support',
          summaryPreview:
            'Email notification withheld because the parent/guardian email address has not yet been verified.',
          reason:
            'Parent email address must be verified before sensitive report notifications can be dispatched.',
        });
        return;
      }

      // Respect parent notification settings
      const isUrgent = Boolean(body.urgentFlag || body.aiSummary.immediateSafetyConcern);
      if (body.notifyUrgentOnly && !isUrgent && !body.notifyOnSubmit) {
        res.json({
          deliveryStatus: 'suppressed_child_safety',
          safeguardingCheckPassed: true,
          smtpConfigured: isSmtpConfigured(),
          subject: 'Important – Your Child May Need Your Support',
          summaryPreview:
            'Notification held per parent preference (urgent-only notifications enabled). Report remains accessible in the authenticated Parent Portal.',
          reason: 'Parent notification preference set to urgent-only.',
        });
        return;
      }

      const baseUrl = (process.env.APP_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
      const securePortalLink = `${baseUrl}/?portal=parent&ref=${encodeURIComponent(body.referenceCode)}`;
      const subject = 'Important – Your Child May Need Your Support';

      const emailText = [
        `Hello ${body.recipientName || 'Parent / Guardian'},`,
        '',
        'UDAAN Safeguarding Notification',
        `Report Reference Number: ${body.referenceCode}`,
        isUrgent
          ? 'Priority Notice: Immediate safety support was flagged for urgent adult attention.'
          : 'Status: Awaiting safeguarding review.',
        '',
        'Reported Summary (Generated from Student Questionnaire):',
        body.aiSummary.reportedFactsSummary,
        '',
        `Category: ${body.aiSummary.incidentCategory}`,
        `Frequency: ${body.aiSummary.frequency}`,
        `Reported Location(s): ${body.aiSummary.reportedLocation}`,
        '',
        'Recommended Next Steps for You:',
        body.aiSummary.recommendedNextSteps,
        '',
        'View Full Report Securely:',
        `Sign in with your verified account at: ${securePortalLink}`,
        '(For child privacy, sensitive details are only accessible after authentication.)',
        '',
        `Safeguarding Note: ${body.aiSummary.disclaimer}`,
      ].join('\n');

      if (isSmtpConfigured()) {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: Number(process.env.SMTP_PORT || 587),
          secure: Number(process.env.SMTP_PORT || 587) === 465,
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
        });

        const info = await transporter.sendMail({
          from: process.env.SMTP_FROM || process.env.SMTP_USER,
          to: body.recipientEmail,
          subject,
          text: emailText,
        });

        res.json({
          deliveryStatus: 'sent_smtp',
          safeguardingCheckPassed: true,
          smtpConfigured: true,
          messageId: info.messageId,
          subject,
          summaryPreview: emailText,
        });
        return;
      }

      // Transparent non-mock status when SMTP credentials are not supplied
      res.json({
        deliveryStatus: 'logged_awaiting_smtp',
        safeguardingCheckPassed: true,
        smtpConfigured: false,
        subject,
        summaryPreview: emailText,
        requiredEnvVars: ['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS', 'SMTP_FROM'],
      });
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : 'Failed to process email notification.';
      console.error('Notification dispatch error:', message);
      res.status(500).json({ error: message });
    }
  });

  // Ensure unknown /api/* routes always return JSON rather than falling through to index.html
  app.use('/api', (_req: Request, res: Response) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  if (isProduction) {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`UDAAN server listening on http://0.0.0.0:${PORT}`);
  });
}

createApp().catch((err) => {
  console.error('Failed to start UDAAN server:', err);
  process.exit(1);
});
