import { useEffect, useMemo, useState } from 'react';
import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  ClipboardList,
  Eye,
  Lock,
  LogOut,
  Search,
  ShieldCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  BOOTSTRAPPED_ADMIN_EMAIL,
  DEFAULT_SCHOOLS,
  slugifySchoolName,
  type AuditLogEntry,
  type BullyingReport,
  type FollowUpNote,
  type NotificationRecord,
  type ReportStatus,
  type SchoolStaffRecord,
} from '../types/udaan';
import { SchoolSelector } from './SchoolSelector';

type DashboardTab = 'cases' | 'audit' | 'team';
type StatusFilter = 'all' | 'urgent' | ReportStatus;

export function SchoolDashboard() {
  const {
    user,
    staffProfile,
    isAdmin,
    isAuthorizedStaff,
    signInWithGoogle,
    logout,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<DashboardTab>('cases');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const [reports, setReports] = useState<BullyingReport[]>([]);
  const [loadingReports, setLoadingReports] = useState(true);
  const [selectedReport, setSelectedReport] = useState<BullyingReport | null>(null);

  const [followUps, setFollowUps] = useState<FollowUpNote[]>([]);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [staffList, setStaffList] = useState<SchoolStaffRecord[]>([]);

  // Follow-up form state
  const [actionTaken, setActionTaken] = useState('');
  const [noteText, setNoteText] = useState('');
  const [nextStatus, setNextStatus] = useState<ReportStatus>('under_review');
  const [savingFollowUp, setSavingFollowUp] = useState(false);

  // Add staff form state (Admin only)
  const [newStaffUid, setNewStaffUid] = useState('');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<
    'counselor' | 'safeguarding_lead' | 'principal'
  >('counselor');
  const [newStaffSchoolId, setNewStaffSchoolId] = useState<string>(DEFAULT_SCHOOLS[0].id);
  const [newStaffCustomSchoolName, setNewStaffCustomSchoolName] = useState('');
  const [staffFeedback, setStaffFeedback] = useState<string | null>(null);

  const isBootstrappedAdmin = Boolean(
    user?.emailVerified &&
      user.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase(),
  );

  useEffect(() => {
    if (!user?.uid || !isAuthorizedStaff) {
      setReports([]);
      setLoadingReports(false);
      return;
    }

    setLoadingReports(true);
    const reportsQuery = isBootstrappedAdmin
      ? query(collection(db, 'reports'), orderBy('createdAt', 'desc'))
      : query(
          collection(db, 'reports'),
          where('staffAccessUids', 'array-contains', user.uid),
        );

    const unsub = onSnapshot(
      reportsQuery,
      (snap) => {
        const rows = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as BullyingReport),
        }));
        rows.sort((a, b) => (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0));
        setReports(rows);
        setLoadingReports(false);
        if (selectedReport) {
          const refreshed = rows.find((r) => r.id === selectedReport.id);
          if (refreshed) setSelectedReport(refreshed);
        }
      },
      (err) => {
        setLoadingReports(false);
        handleFirestoreError(err, OperationType.LIST, 'reports');
      },
    );

    return () => unsub();
  }, [user?.uid, isAuthorizedStaff, isBootstrappedAdmin]);

  // Load follow-ups for selected report
  useEffect(() => {
    if (!selectedReport?.id || !user?.uid || !isAuthorizedStaff) {
      setFollowUps([]);
      return;
    }

    const q = isBootstrappedAdmin
      ? query(
          collection(db, 'follow_ups'),
          where('reportId', '==', selectedReport.id),
        )
      : query(
          collection(db, 'follow_ups'),
          where('reportId', '==', selectedReport.id),
          where('staffAccessUids', 'array-contains', user.uid),
        );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as FollowUpNote) }));
        list.sort((a, b) => (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0));
        setFollowUps(list);
      },
      () => {
        setFollowUps([]);
      },
    );

    return () => unsub();
  }, [selectedReport?.id, user?.uid, isAuthorizedStaff, isBootstrappedAdmin]);

  // Load audit logs, notifications, and staff list for bootstrapped admin / authorized staff
  useEffect(() => {
    if (!user?.uid || !isBootstrappedAdmin) {
      setNotifications([]);
      setAuditLogs([]);
      setStaffList([]);
      return;
    }

    const unsubNotif = onSnapshot(
      query(collection(db, 'notifications'), orderBy('createdAt', 'desc')),
      (snap) => {
        setNotifications(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as NotificationRecord) })),
        );
      },
      () => {},
    );

    const unsubAudit = onSnapshot(
      query(collection(db, 'audit_logs'), orderBy('createdAt', 'desc')),
      (snap) => {
        setAuditLogs(snap.docs.map((d) => ({ id: d.id, ...(d.data() as AuditLogEntry) })));
      },
      () => {},
    );

    const unsubStaff = onSnapshot(
      collection(db, 'school_staff'),
      (snap) => {
        setStaffList(snap.docs.map((d) => d.data() as SchoolStaffRecord));
      },
      () => {},
    );

    return () => {
      unsubNotif();
      unsubAudit();
      unsubStaff();
    };
  }, [user?.uid, isBootstrappedAdmin]);

  const handleOpenReport = async (rep: BullyingReport) => {
    setSelectedReport(rep);
    setNextStatus(rep.status);
    if (!user || !rep.id) return;
    try {
      await addDoc(collection(db, 'audit_logs'), {
        reportId: rep.id,
        schoolId: rep.schoolId,
        actorUid: user.uid,
        actorEmail: user.email || 'staff@udaan.org',
        actorRole: isAdmin ? 'admin' : 'staff',
        action: 'viewed_report',
        createdAt: serverTimestamp(),
      });
    } catch {
      // Non-blocking audit log attempt
    }
  };

  const handleUpdateStatus = async (rep: BullyingReport, status: ReportStatus) => {
    if (!user || !rep.id) return;
    try {
      await updateDoc(doc(db, 'reports', rep.id), {
        status,
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'audit_logs'), {
        reportId: rep.id,
        schoolId: rep.schoolId,
        actorUid: user.uid,
        actorEmail: user.email || 'staff@udaan.org',
        actorRole: isAdmin ? 'admin' : 'staff',
        action: 'updated_status',
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `reports/${rep.id}`);
    }
  };

  const handleAddFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedReport?.id || !actionTaken.trim() || !noteText.trim()) return;

    setSavingFollowUp(true);
    try {
      await addDoc(collection(db, 'follow_ups'), {
        reportId: selectedReport.id,
        schoolId: selectedReport.schoolId,
        authorUid: user.uid,
        authorName: (staffProfile?.name || user.displayName || 'Safeguarding Lead').slice(0, 120),
        actionTaken: actionTaken.trim().slice(0, 160),
        note: noteText.trim().slice(0, 2000),
        statusAfter: nextStatus,
        staffAccessUids: selectedReport.staffAccessUids.slice(0, 20),
        createdAt: serverTimestamp(),
      });

      if (nextStatus !== selectedReport.status) {
        await updateDoc(doc(db, 'reports', selectedReport.id), {
          status: nextStatus,
          updatedAt: serverTimestamp(),
        });
      }

      await addDoc(collection(db, 'audit_logs'), {
        reportId: selectedReport.id,
        schoolId: selectedReport.schoolId,
        actorUid: user.uid,
        actorEmail: user.email || 'staff@udaan.org',
        actorRole: isAdmin ? 'admin' : 'staff',
        action: 'added_followup',
        createdAt: serverTimestamp(),
      });

      setActionTaken('');
      setNoteText('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'follow_ups');
    } finally {
      setSavingFollowUp(false);
    }
  };

  const handleAuthorizeStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setStaffFeedback(null);

    const uid = newStaffUid.trim();
    const email = newStaffEmail.trim();
    const name = newStaffName.trim();
    if (!/^[a-zA-Z0-9_-]{1,128}$/.test(uid)) {
      setStaffFeedback('Please provide a valid Firebase User UID (alphanumeric, hyphens, underscores).');
      return;
    }

    if (newStaffSchoolId === 'custom' && !newStaffCustomSchoolName.trim()) {
      setStaffFeedback('Please type the school name for this staff member.');
      return;
    }

    const school =
      newStaffSchoolId === 'custom'
        ? {
            id: slugifySchoolName(newStaffCustomSchoolName),
            name: newStaffCustomSchoolName.trim().slice(0, 160),
          }
        : DEFAULT_SCHOOLS.find((s) => s.id === newStaffSchoolId) || DEFAULT_SCHOOLS[0];

    try {
      await setDoc(doc(db, 'school_staff', uid), {
        uid,
        email,
        name: name.slice(0, 120),
        staffRole: newStaffRole,
        schoolId: school.id,
        schoolName: school.name,
        authorized: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setNewStaffUid('');
      setNewStaffEmail('');
      setNewStaffName('');
      setNewStaffCustomSchoolName('');
      setStaffFeedback(`Authorized safeguarding access granted to ${email}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `school_staff/${uid}`);
    }
  };

  const kpis = useMemo(() => {
    const total = reports.length;
    const urgent = reports.filter((r) => r.urgentFlag && r.status !== 'resolved').length;
    const awaiting = reports.filter((r) => r.status === 'awaiting_review').length;
    const reviewed = reports.filter(
      (r) => r.status === 'under_review' || r.status === 'resolved',
    ).length;
    return { total, urgent, awaiting, reviewed };
  }, [reports]);

  // Privacy-Safe Non-Identifiable School Analytics
  const analytics = useMemo(() => {
    const categories = new Map<string, number>();
    const locations = new Map<string, number>();
    const frequencies = new Map<string, number>();

    for (const rep of reports) {
      for (const inc of rep.incidents) {
        categories.set(inc, (categories.get(inc) || 0) + 1);
      }
      for (const loc of rep.locations) {
        locations.set(loc, (locations.get(loc) || 0) + 1);
      }
      frequencies.set(rep.frequency, (frequencies.get(rep.frequency) || 0) + 1);
    }

    const sortEntries = (m: Map<string, number>) =>
      Array.from(m.entries()).sort((a, b) => b[1] - a[1]);

    return {
      categories: sortEntries(categories).slice(0, 5),
      locations: sortEntries(locations).slice(0, 5),
      frequencies: sortEntries(frequencies),
    };
  }, [reports]);

  const filteredReports = useMemo(() => {
    return reports.filter((rep) => {
      if (statusFilter === 'urgent' && !rep.urgentFlag) return false;
      if (
        statusFilter !== 'all' &&
        statusFilter !== 'urgent' &&
        rep.status !== statusFilter
      ) {
        return false;
      }
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        return (
          rep.referenceCode.toLowerCase().includes(q) ||
          rep.aiSummary.incidentCategory.toLowerCase().includes(q) ||
          rep.schoolName.toLowerCase().includes(q) ||
          rep.locations.some((l) => l.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [reports, statusFilter, searchTerm]);

  if (!user) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-14">
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">
            School Safeguarding Personnel Sign-In
          </h1>
          <p className="text-sm text-slate-600 mt-2 max-w-lg mx-auto leading-relaxed">
            Access to identifiable student bullying reports, case follow-ups, and school
            safeguarding analytics is restricted to verified, authorized school personnel.
          </p>
          <button
            type="button"
            onClick={() => void signInWithGoogle()}
            className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold cursor-pointer"
          >
            Sign in with Authorized Google Account
          </button>
        </div>
      </div>
    );
  }

  if (!isAuthorizedStaff) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-14">
        <div className="bg-white border border-slate-200 rounded-2xl p-8 space-y-4">
          <div className="flex items-center gap-3 text-amber-700">
            <ShieldCheck className="w-6 h-6 shrink-0" />
            <h1 className="text-xl font-bold text-slate-900">
              Authorized School Safeguarding Access Required
            </h1>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            You are signed in as <strong className="text-slate-900">{user.email}</strong>. To
            protect child privacy, identifiable reports are only accessible to authorized school
            counselors, safeguarding leads, or platform administrators.
          </p>
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-1">
            <p className="font-semibold text-slate-800">Your Firebase Account UID (for staff authorization):</p>
            <p className="font-mono text-slate-700 select-all">{user.uid}</p>
            <p className="text-slate-500 pt-1">
              An administrator can grant safeguarding access to this UID inside the Safeguarding
              Team tab.
            </p>
          </div>
          <button
            type="button"
            onClick={() => void logout()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Switch Account
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <p className="text-xs font-medium text-indigo-700">
            School Safeguarding Console · {user.email}
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Safeguarding &amp; Case Resolution Dashboard
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => setActiveTab('cases')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                activeTab === 'cases'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cases &amp; Analytics
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('audit')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                activeTab === 'audit'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Audit &amp; Notifications
            </button>
            {isAdmin && (
              <button
                type="button"
                onClick={() => setActiveTab('team')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'team'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Safeguarding Team
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={() => void logout()}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </div>

      {activeTab === 'cases' && (
        <div className="space-y-8">
          {/* KPI Overview Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <p className="text-xs font-medium text-slate-500">Total Reports Received</p>
              <p className="text-3xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
                {kpis.total}
              </p>
            </div>
            <div className="bg-white border border-rose-200 rounded-2xl p-5">
              <p className="text-xs font-medium text-rose-700">Urgent Attention Required</p>
              <p className="text-3xl font-bold text-rose-700 mt-2 font-mono tabular-nums">
                {kpis.urgent}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <p className="text-xs font-medium text-slate-500">Awaiting Review</p>
              <p className="text-3xl font-bold text-amber-700 mt-2 font-mono tabular-nums">
                {kpis.awaiting}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <p className="text-xs font-medium text-slate-500">Reviewed / Resolved</p>
              <p className="text-3xl font-bold text-emerald-700 mt-2 font-mono tabular-nums">
                {kpis.reviewed}
              </p>
            </div>
          </div>

          {/* Anonymized School Analytics */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-600" />
                <h2 className="text-base font-semibold text-slate-900">
                  School-Wide Safety Trends (Anonymized)
                </h2>
              </div>
              <p className="text-xs text-slate-500">
                Aggregate patterns only · No student identities exposed in analytics
              </p>
            </div>

            {reports.length === 0 ? (
              <p className="text-sm text-slate-500 py-4">
                Analytics populate automatically as reports are submitted.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                <div>
                  <h3 className="text-xs font-semibold text-slate-700 mb-3">
                    Top Reported Incident Types
                  </h3>
                  <div className="space-y-2.5">
                    {analytics.categories.map(([label, count]) => (
                      <div key={label} className="space-y-1">
                        <div className="flex items-center justify-between text-xs gap-2">
                          <span className="text-slate-700 truncate">{label}</span>
                          <span className="font-mono tabular-nums font-medium text-slate-900">
                            {count}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className="h-full bg-indigo-600 rounded-full"
                            style={{
                              width: `${Math.min(100, (count / reports.length) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-xs font-semibold text-slate-700 mb-3">
                    Frequently Reported Locations
                  </h3>
                  <div className="space-y-2.5">
                    {analytics.locations.map(([label, count]) => (
                      <div key={label} className="space-y-1">
                        <div className="flex items-center justify-between text-xs gap-2">
                          <span className="text-slate-700 truncate">{label}</span>
                          <span className="font-mono tabular-nums font-medium text-slate-900">
                            {count}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className="h-full bg-violet-600 rounded-full"
                            style={{
                              width: `${Math.min(100, (count / reports.length) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-xs font-semibold text-slate-700 mb-3">
                    Incident Frequency Distribution
                  </h3>
                  <div className="space-y-2.5">
                    {analytics.frequencies.map(([label, count]) => (
                      <div key={label} className="space-y-1">
                        <div className="flex items-center justify-between text-xs gap-2">
                          <span className="text-slate-700 truncate">{label}</span>
                          <span className="font-mono tabular-nums font-medium text-slate-900">
                            {count}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className="h-full bg-sky-600 rounded-full"
                            style={{
                              width: `${Math.min(100, (count / reports.length) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Case Management Grid + Individual Report Viewer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <h2 className="text-base font-semibold text-slate-900">
                  Safeguarding Case Queue
                </h2>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search reference or category..."
                    className="pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>
              </div>

              {/* Filter Tabs */}
              <div className="flex flex-wrap gap-1 p-1 bg-slate-100 rounded-xl">
                {(
                  [
                    { key: 'all', label: 'All' },
                    { key: 'urgent', label: 'Urgent' },
                    { key: 'awaiting_review', label: 'Awaiting Review' },
                    { key: 'under_review', label: 'Under Review' },
                    { key: 'resolved', label: 'Resolved' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => setStatusFilter(tab.key)}
                    className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      statusFilter === tab.key
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {loadingReports ? (
                <div className="space-y-3 py-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 rounded-xl bg-slate-100" />
                  ))}
                </div>
              ) : filteredReports.length === 0 ? (
                <div className="py-10 text-center text-sm text-slate-500">
                  No safeguarding cases match this filter yet.
                </div>
              ) : (
                <div className="divide-y divide-slate-200">
                  {filteredReports.map((rep) => {
                    const active = selectedReport?.id === rep.id;
                    return (
                      <button
                        key={rep.id}
                        type="button"
                        onClick={() => void handleOpenReport(rep)}
                        className={`w-full text-left py-3.5 px-3 rounded-xl transition-colors cursor-pointer ${
                          active ? 'bg-indigo-50/70' : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <span className="font-mono font-semibold text-indigo-700">
                            {rep.referenceCode}
                          </span>
                          <div className="flex items-center gap-2">
                            {rep.urgentFlag && (
                              <span className="text-rose-700 font-semibold flex items-center gap-1">
                                <AlertTriangle className="w-3.5 h-3.5" /> Urgent
                              </span>
                            )}
                            <span className="text-slate-500">
                              {rep.status === 'resolved'
                                ? 'Resolved'
                                : rep.status === 'under_review'
                                ? 'Under Review'
                                : 'Awaiting Review'}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm font-medium text-slate-900 mt-1">
                          {rep.aiSummary.incidentCategory}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {rep.schoolName} · {rep.frequency} · {rep.locations.join(', ')}
                        </p>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Right: Individual Case Viewer & Follow-Up Tracker */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-2xl p-6">
              {!selectedReport ? (
                <div className="py-16 text-center space-y-2">
                  <Eye className="w-6 h-6 text-indigo-600 mx-auto" />
                  <p className="text-sm font-semibold text-slate-900">
                    Select a case to view full safeguarding details
                  </p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Opening an identifiable report automatically logs a safeguarding access entry
                    in the audit trail.
                  </p>
                </div>
              ) : (
                <div className="space-y-5">
                  <div className="flex flex-wrap items-start justify-between gap-3 pb-4 border-b border-slate-200">
                    <div>
                      <p className="text-xs font-mono font-semibold text-indigo-700">
                        {selectedReport.referenceCode}
                      </p>
                      <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                        {selectedReport.studentName} ({selectedReport.studentCode})
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {selectedReport.schoolName} · Routing:{' '}
                        {selectedReport.parentSafeToNotify
                          ? 'Parent & School Lead'
                          : 'Counselor Only (Home Blocked)'}
                      </p>
                    </div>

                    <select
                      aria-label="Update case status"
                      value={selectedReport.status}
                      onChange={(e) =>
                        void handleUpdateStatus(
                          selectedReport,
                          e.target.value as ReportStatus,
                        )
                      }
                      className="rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    >
                      <option value="awaiting_review">Awaiting Review</option>
                      <option value="under_review">Under Review</option>
                      <option value="resolved">Resolved</option>
                    </select>
                  </div>

                  {selectedReport.urgentFlag && (
                    <div className="rounded-xl bg-rose-50 border border-rose-200 p-3.5 text-xs text-rose-900 font-medium flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>
                        Immediate Safety Flag: Student responded “
                        {selectedReport.isSafeRightNow}” regarding immediate safety. Prioritize
                        in-person check-in.
                      </span>
                    </div>
                  )}

                  <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-4 space-y-2">
                    <p className="text-xs font-semibold text-indigo-950">
                      Submitted Checklist Factual Summary
                    </p>
                    <p className="text-sm text-slate-800 leading-relaxed">
                      {selectedReport.aiSummary.reportedFactsSummary}
                    </p>
                    <p className="text-xs text-slate-600 pt-1">
                      <strong>Suggested Next Steps:</strong>{' '}
                      {selectedReport.aiSummary.recommendedNextSteps}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                      <p className="text-slate-500">Reported Incidents</p>
                      <p className="font-medium text-slate-900 mt-1">
                        {selectedReport.incidents.join(' · ')}
                      </p>
                    </div>
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                      <p className="text-slate-500">Emotions &amp; Additional Note</p>
                      <p className="font-medium text-slate-900 mt-1">
                        {selectedReport.feelings.join(', ')}
                      </p>
                      {selectedReport.additionalInfo && (
                        <p className="text-slate-700 mt-1 italic">
                          “{selectedReport.additionalInfo}”
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Follow-up Note Form */}
                  <form
                    onSubmit={(e) => void handleAddFollowUp(e)}
                    className="border-t border-slate-200 pt-4 space-y-3"
                  >
                    <h4 className="text-sm font-semibold text-slate-900">
                      Add Follow-Up Action &amp; Resolution Note
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        required
                        maxLength={160}
                        value={actionTaken}
                        onChange={(e) => setActionTaken(e.target.value)}
                        placeholder="Action taken (e.g., Private counselor check-in)"
                        className="rounded-xl border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                      />
                      <select
                        value={nextStatus}
                        onChange={(e) => setNextStatus(e.target.value as ReportStatus)}
                        className="rounded-xl border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                      >
                        <option value="awaiting_review">Status: Awaiting Review</option>
                        <option value="under_review">Status: Under Review</option>
                        <option value="resolved">Status: Resolved</option>
                      </select>
                    </div>
                    <textarea
                      required
                      rows={2}
                      maxLength={2000}
                      value={noteText}
                      onChange={(e) => setNoteText(e.target.value)}
                      placeholder="Document safeguarding steps, support plan, or parent coordination..."
                      className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                    <button
                      type="submit"
                      disabled={savingFollowUp}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold cursor-pointer"
                    >
                      {savingFollowUp ? 'Saving Note...' : 'Save Follow-Up Note'}
                    </button>
                  </form>

                  {/* Follow-up Timeline */}
                  {followUps.length > 0 && (
                    <div className="border-t border-slate-200 pt-4 space-y-2">
                      <h4 className="text-xs font-semibold text-slate-500">
                        Follow-Up History ({followUps.length})
                      </h4>
                      <div className="space-y-2">
                        {followUps.map((fu) => (
                          <div
                            key={fu.id}
                            className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs"
                          >
                            <div className="flex items-center justify-between font-medium text-slate-900">
                              <span>{fu.actionTaken}</span>
                              <span className="text-slate-500">{fu.authorName}</span>
                            </div>
                            <p className="text-slate-700 mt-1">{fu.note}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'audit' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6">
            <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2 mb-4">
              <ClipboardList className="w-4 h-4 text-indigo-600" />
              Safeguarding Audit Trail ({auditLogs.length})
            </h2>
            <div className="divide-y divide-slate-200 max-h-[520px] overflow-y-auto">
              {auditLogs.map((log) => (
                <div key={log.id} className="py-3 text-xs flex items-center justify-between gap-2">
                  <div>
                    <p className="font-medium text-slate-900">
                      {log.action.replace(/_/g, ' ')}
                    </p>
                    <p className="text-slate-500">
                      {log.actorEmail} · {log.actorRole}
                    </p>
                  </div>
                  <span className="font-mono text-slate-500">{log.schoolId}</span>
                </div>
              ))}
              {auditLogs.length === 0 && (
                <p className="text-xs text-slate-500 py-4">No audit events recorded yet.</p>
              )}
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6">
            <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2 mb-4">
              <CheckCircle2 className="w-4 h-4 text-indigo-600" />
              Parent Notification Workflow Log ({notifications.length})
            </h2>
            <div className="divide-y divide-slate-200 max-h-[520px] overflow-y-auto">
              {notifications.map((n) => (
                <div key={n.id} className="py-3 text-xs space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono font-semibold text-indigo-700">
                      {n.referenceCode}
                    </span>
                    <span className="font-mono text-slate-600">{n.deliveryStatus}</span>
                  </div>
                  <p className="text-slate-800 font-medium">{n.recipientEmail}</p>
                  <p className="text-slate-500 line-clamp-2">{n.summaryPreview}</p>
                </div>
              ))}
              {notifications.length === 0 && (
                <p className="text-xs text-slate-500 py-4">No notifications logged yet.</p>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'team' && isAdmin && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={(e) => void handleAuthorizeStaff(e)}
            className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-indigo-600" />
              Authorize School Safeguarding Personnel
            </h2>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Firebase User UID
              </label>
              <input
                type="text"
                required
                value={newStaffUid}
                onChange={(e) => setNewStaffUid(e.target.value)}
                placeholder="Paste staff Firebase UID"
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Staff Email
              </label>
              <input
                type="email"
                required
                value={newStaffEmail}
                onChange={(e) => setNewStaffEmail(e.target.value)}
                placeholder="counselor@school.edu"
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={newStaffName}
                onChange={(e) => setNewStaffName(e.target.value)}
                placeholder="Dr. Meera Sharma"
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs"
              />
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Staff Role
                </label>
                <select
                  value={newStaffRole}
                  onChange={(e) =>
                    setNewStaffRole(
                      e.target.value as 'counselor' | 'safeguarding_lead' | 'principal',
                    )
                  }
                  className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs"
                >
                  <option value="counselor">Counselor</option>
                  <option value="safeguarding_lead">Safeguarding Lead</option>
                  <option value="principal">Principal</option>
                </select>
              </div>
              <SchoolSelector
                label="Assigned School"
                selectedSchoolId={newStaffSchoolId}
                customSchoolName={newStaffCustomSchoolName}
                onSelectSchoolId={setNewStaffSchoolId}
                onChangeCustomSchoolName={setNewStaffCustomSchoolName}
                compact
              />
            </div>
            {staffFeedback && (
              <p className="text-xs text-indigo-800 bg-indigo-50 border border-indigo-200 rounded-xl p-3">
                {staffFeedback}
              </p>
            )}
            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold cursor-pointer"
            >
              Grant Safeguarding Access
            </button>
          </form>

          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6">
            <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2 mb-4">
              <Users className="w-4 h-4 text-indigo-600" />
              Authorized Staff Directory ({staffList.length})
            </h2>
            <div className="divide-y divide-slate-200">
              {staffList.map((member) => (
                <div
                  key={member.uid}
                  className="py-3 flex items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <p className="font-semibold text-slate-900">{member.name}</p>
                    <p className="text-slate-500">
                      {member.email} · {member.staffRole} · {member.schoolName}
                    </p>
                  </div>
                  <span className="font-mono text-emerald-700 font-medium">
                    {member.authorized ? 'Authorized' : 'Suspended'}
                  </span>
                </div>
              ))}
              {staffList.length === 0 && (
                <p className="text-xs text-slate-500 py-4">
                  Platform Admin ({BOOTSTRAPPED_ADMIN_EMAIL}) is active. Add additional school
                  counselors using the form.
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
