import { useEffect, useState } from 'react';
import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Clock,
  FileText,
  Lock,
  MailCheck,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  type AiReportSummary,
  type AppView,
  type BullyingReport,
  type SafeRightNowOption,
  type TrustedAdultChannel,
} from '../types/udaan';
import { EmergencySupportPanel } from './EmergencySupportPanel';

const INCIDENT_OPTIONS = [
  'Someone called me hurtful names.',
  'Someone made fun of me.',
  'Someone threatened me.',
  'Someone physically hurt me.',
  'Someone deliberately excluded me.',
  'Someone spread rumours about me.',
  'Someone bullied me online.',
  'Someone took or damaged my belongings.',
  'Something else.',
] as const;

const FREQUENCY_OPTIONS = [
  'Once',
  'A few times',
  'Every week',
  'Almost every day',
] as const;

const LOCATION_OPTIONS = [
  'Classroom',
  'Playground',
  'School bus',
  'School corridors',
  'Online',
  'Somewhere else',
] as const;

const FEELING_OPTIONS = [
  'Sad',
  'Scared',
  'Lonely',
  'Embarrassed',
  'Angry',
  'Confused',
  'Other',
] as const;

function sanitizeCode(raw: string, fallback: string): string {
  const cleaned = raw.trim().replace(/[^a-zA-Z0-9_-]/g, '-');
  return cleaned.length >= 3 ? cleaned.slice(0, 32) : fallback;
}

function generateReferenceCode(): string {
  const num = Math.floor(1000 + Math.random() * 9000);
  return `UDN-2026-${num}`;
}

const DEFAULT_CHECKLIST_SCHOOL = {
  id: 'udaan-safeguarding',
  name: 'School Safeguarding Team',
};

function deriveIncidentCategory(incidents: string[]): string {
  const tags: string[] = [];
  if (
    incidents.some(
      (i) => i.includes('hurtful names') || i.includes('made fun'),
    )
  ) {
    tags.push('Verbal Bullying');
  }
  if (incidents.some((i) => i.includes('threatened') || i.includes('physically hurt'))) {
    tags.push('Threats / Physical Harm');
  }
  if (incidents.some((i) => i.includes('excluded') || i.includes('rumours'))) {
    tags.push('Social Exclusion & Rumours');
  }
  if (incidents.some((i) => i.includes('online'))) {
    tags.push('Online Bullying');
  }
  if (incidents.some((i) => i.includes('belongings'))) {
    tags.push('Property Interference');
  }
  if (incidents.some((i) => i.includes('Something else')) && tags.length === 0) {
    tags.push('Bullying Concern');
  }
  return (tags.length > 0 ? tags.join(' & ') : 'Reported Bullying Concern').slice(0, 160);
}

function buildChecklistSummary(params: {
  incidents: string[];
  frequency: string;
  locations: string[];
  feelings: string[];
  isSafeRightNow: SafeRightNowOption;
  additionalInfo: string;
}): AiReportSummary {
  const { incidents, frequency, locations, feelings, isSafeRightNow, additionalInfo } = params;
  const incidentCategory = deriveIncidentCategory(incidents);
  const cleanedIncidents = incidents
    .map((item) => item.replace(/\.$/, '').toLowerCase())
    .join('; ');
  const locationsText = locations.join(', ');
  const feelingsText = feelings.join(', ').toLowerCase();
  const hasUrgentIncident = incidents.some(
    (i) => i.includes('threatened') || i.includes('physically hurt'),
  );
  const immediateSafetyConcern =
    isSafeRightNow === 'no' || isSafeRightNow === 'unsure' || hasUrgentIncident;

  const safetySentence =
    isSafeRightNow === 'no'
      ? ' The student indicated they do not feel safe right now.'
      : isSafeRightNow === 'unsure'
      ? ' The student indicated they are not sure whether they are safe right now.'
      : '';

  const noteSentence = additionalInfo
    ? ` Additional details shared by the student: "${additionalInfo}"`
    : '';

  const reportedFactsSummary = (
    `A student submitted a checklist reporting: ${cleanedIncidents}. ` +
    `Frequency: ${frequency}. Location(s): ${locationsText}. ` +
    `Emotions expressed: ${feelingsText}.${safetySentence}${noteSentence}`
  ).slice(0, 2000);

  const recommendedNextSteps = immediateSafetyConcern
    ? 'A trusted adult should check in privately and calmly with the child right away to ensure their immediate physical and emotional safety, listen without judgement, and coordinate with the school safeguarding lead.'
    : 'A trusted adult should speak privately with the child, listen calmly without judgement, and coordinate with the school safeguarding team to help ensure their ongoing safety and wellbeing.';

  return {
    incidentCategory,
    reportedFactsSummary,
    frequency: frequency.slice(0, 120),
    reportedLocation: locationsText.slice(0, 240),
    emotionalImpact: feelings.join(', ').slice(0, 300),
    immediateSafetyConcern,
    recommendedNextSteps: recommendedNextSteps.slice(0, 1200),
    disclaimer:
      'Compiled directly from the student’s submitted checklist answers. A trained adult should review and respond with care.',
  };
}

async function parseJsonSafely(res: Response, endpoint: string): Promise<Record<string, unknown>> {
  const raw = await res.text();
  try {
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    throw new Error(
      `Server returned a non-JSON response (${res.status}) from ${endpoint}. Please ensure the backend server is running.`,
    );
  }
}

export function ChildReportFlow({ onNavigate }: { onNavigate: (view: AppView) => void }) {
  const { user, studentProfile, signInWithGoogle, refreshProfiles } = useAuth();

  const [step, setStep] = useState<number>(1);
  const [incidents, setIncidents] = useState<string[]>([]);
  const [frequency, setFrequency] = useState<(typeof FREQUENCY_OPTIONS)[number] | ''>('');
  const [locations, setLocations] = useState<string[]>([]);
  const [feelings, setFeelings] = useState<string[]>([]);
  const [isSafeRightNow, setIsSafeRightNow] = useState<SafeRightNowOption | ''>('');
  const [additionalInfo, setAdditionalInfo] = useState('');

  const [studentName, setStudentName] = useState('');
  const [studentCode, setStudentCode] = useState('');
  const [trustedAdultChannel, setTrustedAdultChannel] = useState<TrustedAdultChannel>('both');
  const [parentEmailInput, setParentEmailInput] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submittedResult, setSubmittedResult] = useState<{
    referenceCode: string;
    aiSummary: AiReportSummary;
    notificationStatus: string;
    parentSafeToNotify: boolean;
  } | null>(null);

  const [myReports, setMyReports] = useState<BullyingReport[]>([]);

  useEffect(() => {
    if (studentProfile) {
      setStudentName(studentProfile.displayName);
      setStudentCode(studentProfile.studentCode);
      setTrustedAdultChannel(studentProfile.trustedAdultOption);
      if (studentProfile.parentEmail) {
        setParentEmailInput(studentProfile.parentEmail);
      }
    } else if (user?.displayName && !studentName) {
      setStudentName(user.displayName);
    }
  }, [studentProfile, user]);

  useEffect(() => {
    if (!user?.uid) {
      setMyReports([]);
      return;
    }
    const q = query(
      collection(db, 'reports'),
      where('reporterUid', '==', user.uid),
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as BullyingReport),
        }));
        list.sort((a, b) => (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0));
        setMyReports(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'reports');
      },
    );
    return () => unsub();
  }, [user?.uid]);

  const toggleMulti = (list: string[], value: string, setter: (v: string[]) => void) => {
    if (list.includes(value)) {
      setter(list.filter((item) => item !== value));
    } else if (list.length < 10) {
      setter([...list, value]);
    }
  };

  const canProceed = (): boolean => {
    if (step === 1) return incidents.length > 0;
    if (step === 2) return frequency !== '';
    if (step === 3) return locations.length > 0;
    if (step === 4) return feelings.length > 0;
    if (step === 5) return isSafeRightNow !== '';
    return true;
  };

  const parentSafeToNotify = trustedAdultChannel !== 'school_counselor';

  const handleSubmitReport = async () => {
    setSubmitError(null);

    if (!user) {
      setSubmitError('Please sign in with your Google account below to submit securely.');
      return;
    }

    if (!user.emailVerified) {
      setSubmitError('Your account email must be verified before submitting a report.');
      return;
    }

    if (
      incidents.length === 0 ||
      !frequency ||
      locations.length === 0 ||
      feelings.length === 0 ||
      !isSafeRightNow
    ) {
      setSubmitError('Please complete Steps 1 to 5 before submitting.');
      return;
    }

    setSubmitting(true);
    const referenceCode = generateReferenceCode();

    try {
      // 1. Build structured factual summary directly from the student's checklist answers
      const checklistSummary = buildChecklistSummary({
        incidents,
        frequency,
        locations,
        feelings,
        isSafeRightNow,
        additionalInfo: additionalInfo.trim(),
      });

      const safeName = (studentName.trim() || user.displayName || 'Student').slice(0, 120);
      const safeStudentCode = sanitizeCode(
        studentCode,
        `STU-${user.uid.slice(0, 6).toUpperCase()}`,
      );
      const trimmedParentEmail = parentEmailInput.trim();
      const hasValidParentEmail =
        parentSafeToNotify && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedParentEmail);

      // 2. Save or update Student Profile
      try {
        await setDoc(doc(db, 'students', user.uid), {
          studentUid: user.uid,
          displayName: safeName,
          studentCode: safeStudentCode,
          schoolId: DEFAULT_CHECKLIST_SCHOOL.id,
          schoolName: DEFAULT_CHECKLIST_SCHOOL.name,
          ...(hasValidParentEmail ? { parentEmail: trimmedParentEmail } : {}),
          trustedAdultOption: trustedAdultChannel,
          consentConfirmed: true,
          createdAt: studentProfile?.createdAt || serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `students/${user.uid}`);
      }

      // 3. Create Report Document in Firestore
      const reportRef = doc(collection(db, 'reports'));
      const urgentFlag =
        isSafeRightNow === 'no' ||
        isSafeRightNow === 'unsure' ||
        Boolean(checklistSummary.immediateSafetyConcern);

      const reportPayload = {
        referenceCode,
        reporterUid: user.uid,
        studentName: safeName,
        studentCode: safeStudentCode,
        schoolId: DEFAULT_CHECKLIST_SCHOOL.id,
        schoolName: DEFAULT_CHECKLIST_SCHOOL.name,
        ...(hasValidParentEmail ? { parentEmail: trimmedParentEmail } : {}),
        parentSafeToNotify,
        trustedAdultChannel,
        incidents: incidents.slice(0, 10),
        frequency,
        locations: locations.slice(0, 10),
        feelings: feelings.slice(0, 10),
        isSafeRightNow,
        additionalInfo: additionalInfo.trim().slice(0, 2000),
        urgentFlag,
        status: 'awaiting_review' as const,
        staffAccessUids: [] as string[],
        aiSummary: checklistSummary,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      try {
        await setDoc(reportRef, reportPayload);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `reports/${reportRef.id}`);
      }

      // 4. Write audit log for report submission
      try {
        await addDoc(collection(db, 'audit_logs'), {
          reportId: reportRef.id,
          schoolId: DEFAULT_CHECKLIST_SCHOOL.id,
          actorUid: user.uid,
          actorEmail: user.email || 'unknown@udaan.org',
          actorRole: 'student',
          action: 'submitted_report',
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, 'audit_logs');
      }

      // 5. Trigger safeguarded email notification workflow
      const notifyRes = await fetch('/api/notifications/dispatch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          referenceCode,
          recipientEmail: hasValidParentEmail ? trimmedParentEmail : '',
          recipientEmailVerified: hasValidParentEmail,
          recipientName: 'Parent / Guardian',
          parentSafeToNotify,
          trustedAdultChannel,
          urgentFlag,
          notifyOnSubmit: true,
          notifyUrgentOnly: false,
          aiSummary: reportPayload.aiSummary,
        }),
      });

      const notifyData = await parseJsonSafely(notifyRes, '/api/notifications/dispatch');
      const deliveryStatus =
        typeof notifyData.deliveryStatus === 'string'
          ? notifyData.deliveryStatus
          : 'logged_awaiting_smtp';

      try {
        await addDoc(collection(db, 'notifications'), {
          reportId: reportRef.id,
          referenceCode,
          actorUid: user.uid,
          recipientEmail: hasValidParentEmail
            ? trimmedParentEmail
            : 'counselor-desk@school-safeguarding.local',
          recipientType: parentSafeToNotify ? 'parent' : 'school_staff',
          schoolId: DEFAULT_CHECKLIST_SCHOOL.id,
          subject: String(
            notifyData.subject || 'Important – Your Child May Need Your Support',
          ).slice(0, 240),
          summaryPreview: String(
            notifyData.summaryPreview || reportPayload.aiSummary.reportedFactsSummary,
          ).slice(0, 1950),
          deliveryStatus,
          safeguardingCheckPassed: Boolean(notifyData.safeguardingCheckPassed),
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, 'notifications');
      }

      await refreshProfiles();
      setSubmittedResult({
        referenceCode,
        aiSummary: reportPayload.aiSummary,
        notificationStatus: deliveryStatus,
        parentSafeToNotify,
      });
    } catch (err) {
      setSubmitError(
        err instanceof Error ? err.message : 'Unable to submit report right now.',
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (submittedResult) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 space-y-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-mono font-medium text-indigo-700">
                Reference: {submittedResult.referenceCode}
              </p>
              <h2 className="text-2xl font-bold text-slate-900 mt-1">
                Your Checklist Has Been Submitted Safely
              </h2>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                Thank you for speaking up. You did the right thing. A trained safeguarding adult
                will review your checklist carefully and support you.
              </p>
            </div>
          </div>

          {(isSafeRightNow === 'no' || isSafeRightNow === 'unsure') && (
            <div className="mt-6">
              <EmergencySupportPanel urgent compact />
            </div>
          )}

          <div className="mt-8 border-t border-slate-200 pt-6 space-y-5">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Checklist Summary Prepared for Your Trusted Adult
              </h3>
              <p className="mt-2 text-sm text-slate-700 leading-relaxed bg-blue-50/50 border border-blue-100 rounded-xl p-4">
                {submittedResult.aiSummary.reportedFactsSummary}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <p className="text-xs text-slate-500">Category</p>
                <p className="font-medium text-slate-900 mt-0.5">
                  {submittedResult.aiSummary.incidentCategory}
                </p>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <p className="text-xs text-slate-500">Frequency</p>
                <p className="font-medium text-slate-900 mt-0.5">
                  {submittedResult.aiSummary.frequency}
                </p>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <p className="text-xs text-slate-500">Routing</p>
                <p className="font-medium text-slate-900 mt-0.5">
                  {submittedResult.parentSafeToNotify
                    ? 'Verified Parent & School Lead'
                    : 'School Counselor Only'}
                </p>
              </div>
            </div>

            <div className="bg-violet-50/60 border border-violet-200 rounded-xl p-4">
              <p className="text-xs font-semibold text-violet-900">
                Suggested Next Steps for Trusted Adult
              </p>
              <p className="text-sm text-slate-700 mt-1 leading-relaxed">
                {submittedResult.aiSummary.recommendedNextSteps}
              </p>
              <p className="text-xs text-slate-500 mt-2">
                {submittedResult.aiSummary.disclaimer}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <MailCheck className="w-4 h-4 text-indigo-600" />
                <span>
                  Notification workflow:{' '}
                  <strong className="font-medium text-slate-900">
                    {submittedResult.notificationStatus === 'sent_smtp'
                      ? 'Email dispatched to verified parent'
                      : submittedResult.notificationStatus === 'suppressed_child_safety'
                      ? 'Held from home email per child safety selection (routed to counselor)'
                      : submittedResult.notificationStatus === 'blocked_unverified_email'
                      ? 'Saved to school safeguarding queue (no verified parent email entered)'
                      : 'Verified & queued in Parent Portal (configure SMTP in .env for live email delivery)'}
                  </strong>
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setSubmittedResult(null);
                    setStep(1);
                    setIncidents([]);
                    setFrequency('');
                    setLocations([]);
                    setFeelings([]);
                    setIsSafeRightNow('');
                    setAdditionalInfo('');
                  }}
                  className="px-4 py-2 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Submit Another Report
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('home')}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 cursor-pointer"
                >
                  Return Home
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-8">
      {/* Reassuring Header & Step Progress */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <p className="text-xs font-medium text-indigo-700">
              Child-Friendly Help Questionnaire · Confidential Safeguarding Flow
            </p>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
              Tell Us What Happened
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Take your time. You can tap the choices that fit best—there is no wrong answer.
            </p>
          </div>
          <div className="text-right shrink-0">
            <span className="text-sm font-mono font-semibold text-indigo-700 tabular-nums">
              Step {step} of 6
            </span>
          </div>
        </div>

        {/* Visual Progress Bar */}
        <div className="mt-5 mb-8">
          <div className="grid grid-cols-6 gap-2" aria-label={`Progress: Step ${step} of 6`}>
            {[1, 2, 3, 4, 5, 6].map((idx) => (
              <div
                key={idx}
                className={`h-2 rounded-full transition-colors ${
                  idx <= step ? 'bg-indigo-600' : 'bg-slate-200'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Step 1: What happened? */}
        {step === 1 && (
          <div>
            <h2 className="text-xl font-semibold text-slate-900">
              1. What happened?
            </h2>
            <p className="text-sm text-slate-600 mt-1 mb-5">
              You can select more than one option.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {INCIDENT_OPTIONS.map((option) => {
                const selected = incidents.includes(option);
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => toggleMulti(incidents, option, setIncidents)}
                    className={`min-h-[56px] text-left px-4 py-3.5 rounded-xl border text-sm sm:text-base font-medium flex items-center justify-between gap-3 transition-colors cursor-pointer ${
                      selected
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-950'
                        : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    <span>{option}</span>
                    <span
                      className={`w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 ${
                        selected
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {selected && <Check className="w-4 h-4" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 2: How often does this happen? */}
        {step === 2 && (
          <div>
            <h2 className="text-xl font-semibold text-slate-900">
              2. How often does this happen?
            </h2>
            <p className="text-sm text-slate-600 mt-1 mb-5">
              Choose the option that feels closest.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {FREQUENCY_OPTIONS.map((option) => {
                const selected = frequency === option;
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setFrequency(option)}
                    className={`min-h-[60px] text-left px-5 py-4 rounded-xl border text-base font-medium flex items-center justify-between gap-3 transition-colors cursor-pointer ${
                      selected
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-950'
                        : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    <span>{option}</span>
                    <span
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        selected ? 'border-indigo-600' : 'border-slate-300'
                      }`}
                    >
                      {selected && <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 3: Where does it happen? */}
        {step === 3 && (
          <div>
            <h2 className="text-xl font-semibold text-slate-900">
              3. Where does it happen?
            </h2>
            <p className="text-sm text-slate-600 mt-1 mb-5">
              Select all places where this has happened.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {LOCATION_OPTIONS.map((option) => {
                const selected = locations.includes(option);
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => toggleMulti(locations, option, setLocations)}
                    className={`min-h-[56px] text-left px-4 py-3.5 rounded-xl border text-base font-medium flex items-center justify-between gap-3 transition-colors cursor-pointer ${
                      selected
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-950'
                        : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    <span>{option}</span>
                    <span
                      className={`w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 ${
                        selected
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {selected && <Check className="w-4 h-4" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 4: How do you feel? */}
        {step === 4 && (
          <div>
            <h2 className="text-xl font-semibold text-slate-900">
              4. How do you feel?
            </h2>
            <p className="text-sm text-slate-600 mt-1 mb-5">
              All feelings are okay. Select as many as you want to share.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {FEELING_OPTIONS.map((option) => {
                const selected = feelings.includes(option);
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => toggleMulti(feelings, option, setFeelings)}
                    className={`min-h-[56px] text-left px-4 py-3.5 rounded-xl border text-base font-medium flex items-center justify-between gap-3 transition-colors cursor-pointer ${
                      selected
                        ? 'bg-violet-50 border-indigo-600 text-indigo-950'
                        : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    <span>{option}</span>
                    <span
                      className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 ${
                        selected
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {selected && <Check className="w-3.5 h-3.5" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 5: Are you safe right now? */}
        {step === 5 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-slate-900">
                5. Are you safe right now?
              </h2>
              <p className="text-sm text-slate-600 mt-1 mb-5">
                If you are in danger right now, we will show immediate help right away.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { value: 'yes' as const, label: 'Yes, I am safe' },
                  { value: 'no' as const, label: 'No, I do not feel safe' },
                  { value: 'unsure' as const, label: "I'm not sure" },
                ].map((opt) => {
                  const selected = isSafeRightNow === opt.value;
                  const isUrgentChoice = opt.value !== 'yes';
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setIsSafeRightNow(opt.value)}
                      className={`min-h-[64px] px-5 py-4 rounded-xl border text-base font-semibold text-center transition-colors cursor-pointer ${
                        selected
                          ? isUrgentChoice
                            ? 'bg-rose-50 border-rose-500 text-rose-900'
                            : 'bg-emerald-50 border-emerald-600 text-emerald-950'
                          : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {(isSafeRightNow === 'no' || isSafeRightNow === 'unsure') && (
              <EmergencySupportPanel urgent />
            )}
          </div>
        )}

        {/* Step 6: Additional Info, Trusted Adult Choice, Review & Submit */}
        {step === 6 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-slate-900">
                6. Additional Information &amp; Review
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                Anything else you share is optional. Review your answers and choose who should
                support you.
              </p>
            </div>

            <div>
              <label
                htmlFor="additional-info"
                className="block text-sm font-semibold text-slate-900 mb-2"
              >
                Would you like to tell us anything else? (Optional)
              </label>
              <textarea
                id="additional-info"
                rows={4}
                maxLength={2000}
                value={additionalInfo}
                onChange={(e) => setAdditionalInfo(e.target.value)}
                placeholder="You can share who was nearby, when it happened, or anything else that helps an adult understand..."
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
              <p className="text-xs text-slate-500 mt-1 text-right tabular-nums">
                {additionalInfo.length} / 2000 characters
              </p>
            </div>

            {/* Student Details & Safe Adult Routing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Your First Name or Nickname
                </label>
                <input
                  type="text"
                  maxLength={120}
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="e.g., Aarav"
                  className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Student ID / Code (Optional)
                </label>
                <input
                  type="text"
                  maxLength={32}
                  value={studentCode}
                  onChange={(e) => setStudentCode(e.target.value)}
                  placeholder="e.g., STU-1042"
                  className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
            </div>

            {/* Safe Adult Choice */}
            <div className="bg-blue-50/50 border border-blue-200 rounded-2xl p-5 space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  Who is safest to receive this report?
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  If letting someone at home know could put you in danger or cause harm, choose
                  “School Counselor Only.”
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setTrustedAdultChannel('both')}
                  className={`text-left p-4 rounded-xl border transition-colors cursor-pointer ${
                    trustedAdultChannel !== 'school_counselor'
                      ? 'bg-white border-indigo-600 text-slate-900'
                      : 'bg-white/60 border-slate-200 text-slate-700'
                  }`}
                >
                  <p className="text-sm font-semibold">
                    Verified Parent / Guardian &amp; School Team
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    Sends a calm summary to your verified parent/guardian and your school
                    safeguarding lead.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setTrustedAdultChannel('school_counselor')}
                  className={`text-left p-4 rounded-xl border transition-colors cursor-pointer ${
                    trustedAdultChannel === 'school_counselor'
                      ? 'bg-white border-indigo-600 text-slate-900'
                      : 'bg-white/60 border-slate-200 text-slate-700'
                  }`}
                >
                  <p className="text-sm font-semibold">
                    School Counselor / Safeguarding Lead Only
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    Does not email home. Routes privately to authorized school safeguarding
                    counselors.
                  </p>
                </button>
              </div>

              {trustedAdultChannel !== 'school_counselor' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Parent / Guardian Email (links report to their verified Parent Portal)
                  </label>
                  <input
                    type="email"
                    maxLength={254}
                    value={parentEmailInput}
                    onChange={(e) => setParentEmailInput(e.target.value)}
                    placeholder="parent@example.com"
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>
              )}
            </div>

            {/* Review Answers Summary */}
            <div className="border border-slate-200 rounded-2xl p-5 bg-slate-50/70 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                Review Your Answers Before Sending
              </h3>
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <dt className="text-slate-500">What happened</dt>
                  <dd className="text-slate-900 font-medium mt-0.5">{incidents.join(' · ')}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">How often</dt>
                  <dd className="text-slate-900 font-medium mt-0.5">{frequency}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">Where</dt>
                  <dd className="text-slate-900 font-medium mt-0.5">{locations.join(' · ')}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">How you feel</dt>
                  <dd className="text-slate-900 font-medium mt-0.5">{feelings.join(' · ')}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">Safe right now</dt>
                  <dd className="text-slate-900 font-medium mt-0.5">
                    {isSafeRightNow === 'yes'
                      ? 'Yes'
                      : isSafeRightNow === 'no'
                      ? 'No (Urgent Support Flagged)'
                      : "I'm not sure (Support Flagged)"}
                  </dd>
                </div>
              </dl>
            </div>

            {/* Clear Pre-Submission Transparency Notice */}
            <div className="rounded-2xl border border-indigo-200 bg-indigo-50/50 p-5 space-y-2">
              <h3 className="text-sm font-semibold text-indigo-950 flex items-center gap-2">
                <Lock className="w-4 h-4 text-indigo-600" />
                Who Will Receive This Report &amp; What Is Shared
              </h3>
              <p className="text-xs text-slate-700 leading-relaxed">
                {parentSafeToNotify
                  ? 'Your checklist answers and summary will be shared securely with authorized school safeguarding staff and your verified parent/guardian account. Other students can never see your report.'
                  : 'Your checklist answers and summary will be shared privately ONLY with authorized school safeguarding staff. No email will be sent home.'}
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Confidentiality note: UDAAN protects your privacy, but we never promise total
                secrecy when a child’s safety is at risk—trusted adults are alerted specifically so
                they can help keep you safe.
              </p>
            </div>

            {!user && (
              <div className="rounded-2xl border border-amber-200 bg-amber-50/70 p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-slate-900">
                    Sign in to Send Your Report Securely
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    Signing in with Google verifies your identity so your report stays protected
                    under your private account. All your answers above are saved.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => void signInWithGoogle()}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-2"
                >
                  <UserCheck className="w-4 h-4" />
                  Sign in with Google
                </button>
              </div>
            )}

            {submitError && (
              <div
                role="alert"
                className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800 flex items-start gap-2.5"
              >
                <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{submitError}</span>
              </div>
            )}
          </div>
        )}

        {/* Navigation Footer Buttons */}
        <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => (step > 1 ? setStep(step - 1) : onNavigate('home'))}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-sm font-medium text-slate-700 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            {step > 1 ? 'Back' : 'Cancel'}
          </button>

          {step < 6 ? (
            <button
              type="button"
              disabled={!canProceed()}
              onClick={() => setStep(step + 1)}
              className={`inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                canProceed()
                  ? 'bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              Continue
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              disabled={submitting || !user}
              onClick={() => void handleSubmitReport()}
              className={`inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold transition-colors ${
                submitting || !user
                  ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              {submitting ? 'Submitting Checklist...' : 'Submit Checklist'}
            </button>
          )}
        </div>
      </div>

      {/* Signed-in Student's Own Submitted Reports */}
      {user && myReports.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
          <h3 className="text-lg font-semibold text-slate-900">Your Submitted Reports</h3>
          <p className="text-xs text-slate-500 mt-1">
            Only visible to you, your authorized school safeguarding team, and your verified
            parent (when selected).
          </p>
          <div className="mt-4 divide-y divide-slate-200">
            {myReports.map((rep) => (
              <div
                key={rep.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-mono font-medium text-indigo-700">
                      {rep.referenceCode}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{rep.aiSummary.incidentCategory}</span>
                  </div>
                  <p className="text-sm text-slate-800 mt-1 line-clamp-2">
                    {rep.aiSummary.reportedFactsSummary}
                  </p>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700 shrink-0">
                  <Clock className="w-3.5 h-3.5 text-indigo-600" />
                  <span>
                    {rep.status === 'resolved'
                      ? 'Resolved'
                      : rep.status === 'under_review'
                      ? 'Under Review'
                      : 'Awaiting Review'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
