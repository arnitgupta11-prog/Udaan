import { useState } from 'react';
import { PhoneCall, HeartHandshake, ShieldAlert } from 'lucide-react';

type RegionKey = 'india' | 'us' | 'uk' | 'global';

const HELPLINES: Record<
  RegionKey,
  {
    label: string;
    emergencyNumber: string;
    childHelplineName: string;
    childHelplineNumber: string;
    notes: string;
  }
> = {
  india: {
    label: 'India',
    emergencyNumber: '112',
    childHelplineName: 'CHILDLINE India (24/7 Free Child Support)',
    childHelplineNumber: '1098',
    notes: 'You can also call Tele-MANAS mental health support on 14416.',
  },
  us: {
    label: 'United States',
    emergencyNumber: '911',
    childHelplineName: 'StopBullying / 988 Lifeline & Crisis Text Line',
    childHelplineNumber: '988 (or text HOME to 741741)',
    notes: 'Childhelp National Child Abuse Hotline: 1-800-422-4453.',
  },
  uk: {
    label: 'United Kingdom',
    emergencyNumber: '999',
    childHelplineName: 'Childline UK (Free & Confidential)',
    childHelplineNumber: '0800 1111',
    notes: 'NSPCC Helpline for adults worried about a child: 0808 800 5000.',
  },
  global: {
    label: 'International',
    emergencyNumber: 'Local Emergency Services',
    childHelplineName: 'Child Helpline International Directory',
    childHelplineNumber: 'Find your local number via your school office',
    notes: 'Walk directly to a teacher, school nurse, principal, or trusted family adult.',
  },
};

export function EmergencySupportPanel({
  urgent = false,
  compact = false,
}: {
  urgent?: boolean;
  compact?: boolean;
}) {
  const [region, setRegion] = useState<RegionKey>('india');
  const active = HELPLINES[region];

  return (
    <div
      role={urgent ? 'alert' : 'region'}
      aria-label="Immediate safety and emergency support guidance"
      className={`rounded-2xl border ${
        urgent
          ? 'bg-rose-50/80 border-rose-200 text-slate-900'
          : 'bg-blue-50/60 border-blue-200 text-slate-900'
      } ${compact ? 'p-5' : 'p-6 sm:p-8'}`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-5">
        <div className="flex items-start gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              urgent
                ? 'bg-rose-100 text-rose-700'
                : 'bg-indigo-100 text-indigo-700'
            }`}
          >
            {urgent ? (
              <ShieldAlert className="w-5 h-5" />
            ) : (
              <HeartHandshake className="w-5 h-5" />
            )}
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">
              {urgent
                ? 'Your Safety Matters Right Now — Get Immediate Help'
                : 'Emergency & Trusted Adult Support Guidance'}
            </h3>
            <p className="text-sm text-slate-700 mt-1">
              {urgent
                ? 'You do not have to wait for this form to be processed. Please move to a safe, supervised area right away and tell an adult you trust.'
                : 'If you or someone near you is in immediate danger, contact a trusted adult or local emergency support right away.'}
            </p>
          </div>
        </div>

        <div
          className="inline-flex items-center gap-1 p-1 bg-white border border-slate-200 rounded-xl shrink-0 self-start"
          role="tablist"
          aria-label="Select region for helpline numbers"
        >
          {(Object.keys(HELPLINES) as RegionKey[]).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setRegion(key)}
              className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                region === key
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {HELPLINES[key].label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200/80 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Step 1 · Move to Safety</p>
          <p className="text-sm font-semibold text-slate-900 mt-1">
            Stay near a teacher, counselor, or family member
          </p>
          <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
            Walk to the school office, library, nurse’s room, or a bright public space where an
            adult can see and support you.
          </p>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Step 2 · Free Child Helpline</p>
          <p className="text-sm font-semibold text-slate-900 mt-1 flex items-center gap-1.5">
            <PhoneCall className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="font-mono tabular-nums">{active.childHelplineNumber}</span>
          </p>
          <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
            {active.childHelplineName}. {active.notes}
          </p>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Step 3 · Urgent Danger</p>
          <p className="text-sm font-semibold text-slate-900 mt-1 font-mono tabular-nums">
            Call {active.emergencyNumber}
          </p>
          <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
            If someone is hurt or threatening immediate physical harm, ask an adult to call
            emergency services or call directly.
          </p>
        </div>
      </div>
    </div>
  );
}
