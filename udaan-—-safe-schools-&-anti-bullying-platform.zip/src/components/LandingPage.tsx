import {
  ArrowRight,
  BookOpen,
  Building2,
  Lock,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import type { AppView } from '../types/udaan';
import { ResilientImage } from './ResilientImage';
import { EmergencySupportPanel } from './EmergencySupportPanel';

interface LandingPageProps {
  onNavigate: (view: AppView) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  const workflowSteps = [
    {
      num: '01.',
      title: 'Share at Your Own Pace',
      description:
        'Answer simple, gentle questions by tapping clear choices. You never have to explain everything face-to-face if you feel nervous.',
    },
    {
      num: '02.',
      title: 'Immediate Safety Check',
      description:
        'If you tell us you do not feel safe right now, UDAAN immediately displays calm safety steps and helpline numbers without waiting.',
    },
    {
      num: '03.',
      title: 'Structured Checklist Summary',
      description:
        'Your checklist answers are organized into a clear, respectful summary without exaggerating, guessing, or blaming.',
    },
    {
      num: '04.',
      title: 'Trusted Adult Support',
      description:
        'Your verified parent or designated school safeguarding counselor receives the summary securely and steps in to support you.',
    },
  ];

  return (
    <div className="bg-[#F8FAFC]">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-blue-50/70 via-indigo-50/30 to-[#F8FAFC] border-b border-slate-200/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center">
              <p className="text-sm font-medium text-indigo-700 mb-3">
                UDAAN School Child-Safeguarding Platform
              </p>

              <h1 className="text-3xl sm:text-4xl lg:text-[2.75rem] font-bold tracking-tight text-slate-900 leading-[1.15] text-balance">
                Every Child Deserves to Feel Safe, Heard and Respected.
              </h1>

              <p className="mt-5 text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
                UDAAN helps students speak up about bullying gently and privately—without the
                pressure of explaining everything in person first—and connects trusted parents and
                school counselors with clear, factual support summaries.
              </p>

              <div className="mt-6 rounded-2xl bg-white border border-indigo-100 px-5 py-4 max-w-xl">
                <p className="text-sm sm:text-base font-medium text-indigo-950 leading-relaxed">
                  “You are not alone. You deserve to feel safe. Asking for help is always okay.”
                </p>
              </div>

              <div className="mt-7 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('report')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-base font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-indigo-600"
                >
                  I Need Help
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('learn')}
                  className="inline-flex items-center gap-2 px-5 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <BookOpen className="w-4 h-4 text-indigo-600" />
                  Learn About Bullying
                </button>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('parent')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-50/80 hover:bg-blue-100/70 text-indigo-900 border border-blue-200/80 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <UserCheck className="w-4 h-4 text-indigo-600" />
                  Parent / Guardian Login
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('dashboard')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-violet-50/80 hover:bg-violet-100/70 text-indigo-900 border border-violet-200/80 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Building2 className="w-4 h-4 text-violet-700" />
                  School Dashboard
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 flex">
              <div className="w-full rounded-2xl overflow-hidden border border-slate-200/90 bg-white">
                <ResilientImage
                  src="/src/assets/images/hero_udaan_safe_school_1795013474975.jpg"
                  alt="Diverse students walking calmly together in a sunlit school courtyard with a supportive teacher nearby"
                  fallbackTitle="Safe & Supportive Schools"
                  className="w-full h-72 sm:h-96 lg:h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How UDAAN Works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-2xl mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            How UDAAN Supports Every Step
          </h2>
          <p className="mt-2.5 text-base text-slate-600 leading-relaxed">
            Built with child-safeguarding specialists so speaking up feels calm, predictable, and
            genuinely helpful.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 border-t border-slate-200">
          {workflowSteps.map((step) => (
            <div
              key={step.num}
              className="py-6 md:pr-8 lg:px-6 lg:first:pl-0 border-b lg:border-b-0 lg:border-r last:border-r-0 border-slate-200"
            >
              <span className="text-sm font-mono font-medium text-indigo-600">{step.num}</span>
              <h3 className="mt-2 text-lg font-semibold text-slate-900">{step.title}</h3>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Privacy, Safety & Alternative Trusted Adult */}
      <section className="bg-white border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <div className="inline-flex items-center gap-2 text-sm font-medium text-indigo-700 mb-3">
                <Lock className="w-4 h-4" />
                Privacy &amp; Child Safety Commitments
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight text-balance">
                Clear boundaries, honest confidentiality, and safe adult choices.
              </h2>
              <p className="mt-3 text-base text-slate-600 leading-relaxed">
                Children deserve clarity about what happens when they ask for help. We explain
                every step in plain language before any report is sent.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('privacy')}
                className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-indigo-700 hover:text-indigo-800 cursor-pointer"
              >
                Read full privacy &amp; safety policy
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="rounded-2xl border border-slate-200 bg-[#F8FAFC] p-6">
                <ShieldCheck className="w-5 h-5 text-indigo-600 mb-3" />
                <h3 className="text-base font-semibold text-slate-900">
                  Alternative Trusted Adult Option
                </h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  If contacting a parent or guardian could put a child at risk at home, the child
                  can route their report solely to an authorized school counselor.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-[#F8FAFC] p-6">
                <Lock className="w-5 h-5 text-indigo-600 mb-3" />
                <h3 className="text-base font-semibold text-slate-900">
                  Verified Access &amp; Audit Logging
                </h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  Sensitive reports are never sent to unverified emails. Only verified guardians and
                  authorized school safeguarding personnel can access case details.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-[#F8FAFC] p-6">
                <UserCheck className="w-5 h-5 text-indigo-600 mb-3" />
                <h3 className="text-base font-semibold text-slate-900">
                  Honest About Confidentiality
                </h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  We never promise absolute secrecy when a child may be in danger. When help is
                  needed, information is shared strictly with designated safeguarding adults.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-[#F8FAFC] p-6">
                <Building2 className="w-5 h-5 text-indigo-600 mb-3" />
                <h3 className="text-base font-semibold text-slate-900">
                  Human-Led Decisions Only
                </h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  UDAAN organizes reported checklist facts clearly—it never judges truth, labels
                  peers, diagnoses students, or makes disciplinary decisions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Support Guidance */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <EmergencySupportPanel />
      </section>
    </div>
  );
}
