import { useEffect, useState } from 'react';
import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import {
  CheckCircle2,
  LogOut,
  Mail,
  ShieldCheck,
  UserCheck,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  DEFAULT_SCHOOLS,
  slugifySchoolName,
  type BullyingReport,
  type NotificationRecord,
} from '../types/udaan';
import { SchoolSelector } from './SchoolSelector';

export function ParentPortal() {
  const { user, parentProfile, signInWithGoogle, logout, refreshProfiles } = useAuth();

  const [name, setName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [childName, setChildName] = useState('');
  const [studentCode, setStudentCode] = useState('');
  const [schoolId, setSchoolId] = useState<string>(DEFAULT_SCHOOLS[0].id);
  const [customSchoolName, setCustomSchoolName] = useState('');
  const [notifyOnSubmit, setNotifyOnSubmit] = useState(true);
  const [notifyUrgentOnly, setNotifyUrgentOnly] = useState(false);
  const [consentConfirmed, setConsentConfirmed] = useState(false);

  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [linkedReports, setLinkedReports] = useState<BullyingReport[]>([]);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [selectedReport, setSelectedReport] = useState<BullyingReport | null>(null);

  useEffect(() => {
    if (parentProfile) {
      setName(parentProfile.name);
      setContactEmail(parentProfile.email);
      setChildName(parentProfile.childName);
      setStudentCode(parentProfile.studentCode);
      const isListed = DEFAULT_SCHOOLS.some((s) => s.id === parentProfile.schoolId);
      if (isListed) {
        setSchoolId(parentProfile.schoolId);
        setCustomSchoolName('');
      } else {
        setSchoolId('custom');
        setCustomSchoolName(parentProfile.schoolName);
      }
      setNotifyOnSubmit(parentProfile.notifyOnSubmit);
      setNotifyUrgentOnly(parentProfile.notifyUrgentOnly);
      setConsentConfirmed(parentProfile.consentConfirmed);
    } else if (user) {
      setName(user.displayName || '');
      setContactEmail(user.email || '');
    }
  }, [parentProfile, user]);

  useEffect(() => {
    if (!user?.uid || !user.emailVerified || !user.email) {
      setLinkedReports([]);
      setNotifications([]);
      return;
    }

    const qByEmail = query(
      collection(db, 'reports'),
      where('parentEmail', '==', user.email),
      where('parentSafeToNotify', '==', true),
    );

    const unsubReports = onSnapshot(
      qByEmail,
      (snap) => {
        const list = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as BullyingReport),
        }));
        list.sort((a, b) => (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0));
        setLinkedReports(list);
        if (list.length > 0 && !selectedReport) {
          setSelectedReport(list[0]);
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'reports');
      },
    );

    const qNotifications = query(
      collection(db, 'notifications'),
      where('recipientUid', '==', user.uid),
    );

    const unsubNotifs = onSnapshot(
      qNotifications,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as NotificationRecord) }));
        list.sort((a, b) => (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0));
        setNotifications(list);
      },
      () => {
        // Fallback query by actorUid if recipientUid wasn't set
      },
    );

    return () => {
      unsubReports();
      unsubNotifs();
    };
  }, [user?.uid, user?.emailVerified, user?.email]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaveError(null);
    setSaveMessage(null);

    if (!user.emailVerified) {
      setSaveError('Please use a verified email address before saving parent settings.');
      return;
    }
    if (!consentConfirmed) {
      setSaveError('Please confirm parent/guardian consent to continue.');
      return;
    }

    const cleanedCode = studentCode
      .trim()
      .replace(/[^a-zA-Z0-9_-]/g, '-')
      .slice(0, 32);
    if (cleanedCode.length < 3) {
      setSaveError('Please enter a Student Identifier of at least 3 characters (letters, numbers, or hyphens).');
      return;
    }

    const trimmedEmail = contactEmail.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setSaveError('Please enter a valid email address.');
      return;
    }

    if (schoolId === 'custom' && !customSchoolName.trim()) {
      setSaveError('Please type your child’s school name.');
      return;
    }

    const school =
      schoolId === 'custom'
        ? {
            id: slugifySchoolName(customSchoolName),
            name: customSchoolName.trim().slice(0, 160),
          }
        : DEFAULT_SCHOOLS.find((s) => s.id === schoolId) || DEFAULT_SCHOOLS[0];
    const emailChanged = Boolean(parentProfile && parentProfile.email !== trimmedEmail);

    setSaving(true);
    try {
      await setDoc(doc(db, 'parents', user.uid), {
        parentUid: user.uid,
        name: name.trim().slice(0, 120) || 'Parent / Guardian',
        email: trimmedEmail,
        emailVerified: Boolean(user.emailVerified),
        childName: childName.trim().slice(0, 120) || 'Child',
        studentCode: cleanedCode,
        schoolId: school.id,
        schoolName: school.name,
        notifyOnSubmit,
        notifyUrgentOnly,
        consentConfirmed: true,
        createdAt: parentProfile?.createdAt || serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      if (emailChanged) {
        await addDoc(collection(db, 'audit_logs'), {
          schoolId: school.id,
          actorUid: user.uid,
          actorEmail: user.email || trimmedEmail,
          actorRole: 'parent',
          action: 'updated_parent_email',
          createdAt: serverTimestamp(),
        });
      }

      await refreshProfiles();
      setSaveMessage(
        emailChanged
          ? 'Parent profile & updated email address saved. Audit log recorded.'
          : 'Parent / guardian safeguarding profile saved.',
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `parents/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  if (!user) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-14">
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center mx-auto mb-4">
            <UserCheck className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">
            Parent / Guardian Verified Portal
          </h1>
          <p className="text-sm text-slate-600 mt-2 max-w-lg mx-auto leading-relaxed">
            Sign in with your verified Google account to register your guardian profile, link your
            child’s student identifier, manage email preferences, and view protected report
            summaries.
          </p>
          <button
            type="button"
            onClick={() => void signInWithGoogle()}
            className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold cursor-pointer"
          >
            Sign in with Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <p className="text-xs font-medium text-indigo-700">
            Verified Guardian Workspace · {user.email}
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Parent &amp; Guardian Support Portal
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            {user.emailVerified ? 'Verified Email Active' : 'Verification Pending'}
          </span>
          <button
            type="button"
            onClick={() => void logout()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Parent Registration & Notification Preferences */}
        <form
          onSubmit={(e) => void handleSaveProfile(e)}
          className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
        >
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Guardian Profile &amp; Email Settings
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Sensitive alerts are only sent to verified parent emails when safeguarding rules
              permit.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Parent / Guardian Name
            </label>
            <input
              type="text"
              required
              maxLength={120}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Verified Notification Email Address (Editable)
            </label>
            <input
              type="email"
              required
              maxLength={254}
              value={contactEmail}
              onChange={(e) => setContactEmail(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Child’s Name
              </label>
              <input
                type="text"
                required
                maxLength={120}
                value={childName}
                onChange={(e) => setChildName(e.target.value)}
                placeholder="e.g., Ananya"
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Assigned Student ID
              </label>
              <input
                type="text"
                required
                maxLength={32}
                value={studentCode}
                onChange={(e) => setStudentCode(e.target.value)}
                placeholder="e.g., STU-1042"
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>
          </div>

          <SchoolSelector
            label="School Name"
            selectedSchoolId={schoolId}
            customSchoolName={customSchoolName}
            onSelectSchoolId={setSchoolId}
            onChangeCustomSchoolName={setCustomSchoolName}
          />

          <div className="pt-2 space-y-2.5 border-t border-slate-200">
            <p className="text-xs font-semibold text-slate-700">Notification Preferences</p>
            <label className="flex items-start gap-2.5 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={notifyOnSubmit}
                onChange={(e) => setNotifyOnSubmit(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-indigo-600"
              />
              <span>Email me a secure summary whenever a linked report passes safeguarding review</span>
            </label>
            <label className="flex items-start gap-2.5 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={notifyUrgentOnly}
                onChange={(e) => setNotifyUrgentOnly(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-indigo-600"
              />
              <span>Prioritize urgent safety alerts only</span>
            </label>
          </div>

          <label className="flex items-start gap-2.5 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-xl p-3 cursor-pointer">
            <input
              type="checkbox"
              checked={consentConfirmed}
              onChange={(e) => setConsentConfirmed(e.target.checked)}
              className="mt-0.5 rounded border-slate-300 text-indigo-600"
            />
            <span>
              I confirm I am the parent or legal guardian and consent to safeguarding alerts for my
              child in accordance with UDAAN’s privacy policy.
            </span>
          </label>

          {saveError && (
            <p className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-xl p-3 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {saveError}
            </p>
          )}
          {saveMessage && (
            <p className="text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              {saveMessage}
            </p>
          )}

          <button
            type="submit"
            disabled={saving}
            className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold transition-colors cursor-pointer"
          >
            {saving ? 'Saving Profile...' : 'Save Parent Profile'}
          </button>
        </form>

        {/* Right: Linked Reports & Parent Guidance */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6">
            <h2 className="text-lg font-semibold text-slate-900">
              Linked Safeguarding Reports ({linkedReports.length})
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Reports appear here only when linked to your verified email ({user.email}) and
              cleared by child-safety routing.
            </p>

            {linkedReports.length === 0 ? (
              <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-6 text-center">
                <ShieldCheck className="w-6 h-6 text-indigo-600 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-900">No linked reports yet</p>
                <p className="text-xs text-slate-600 mt-1 max-w-md mx-auto">
                  When a student submits a checklist with your verified email ({user.email}) and
                  allows parent notification, the summary and support guidance will appear
                  here immediately.
                </p>
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                <div className="flex flex-wrap gap-2">
                  {linkedReports.map((rep) => (
                    <button
                      key={rep.id}
                      type="button"
                      onClick={() => setSelectedReport(rep)}
                      className={`px-3 py-2 rounded-xl border text-xs font-mono font-medium transition-colors cursor-pointer ${
                        selectedReport?.id === rep.id
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {rep.referenceCode}
                    </button>
                  ))}
                </div>

                {selectedReport && (
                  <div className="border border-slate-200 rounded-2xl p-5 bg-[#F8FAFC] space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200">
                      <div className="text-xs text-slate-600">
                        <span className="font-mono font-semibold text-indigo-700">
                          {selectedReport.referenceCode}
                        </span>
                        <span aria-hidden="true"> · </span>
                        <span>{selectedReport.schoolName}</span>
                        <span aria-hidden="true"> · </span>
                        <span>Student: {selectedReport.studentName}</span>
                      </div>
                      <span className="text-xs font-semibold text-slate-800">
                        Status:{' '}
                        {selectedReport.status === 'resolved'
                          ? 'Resolved'
                          : selectedReport.status === 'under_review'
                          ? 'Under School Review'
                          : 'Awaiting Review'}
                      </span>
                    </div>

                    {selectedReport.urgentFlag && (
                      <div className="rounded-xl bg-rose-50 border border-rose-200 p-3.5 text-xs text-rose-900 font-medium">
                        Immediate Safety Check Flagged: Please check in calmly with your child
                        right away to make sure they feel physically and emotionally safe.
                      </div>
                    )}

                    <div>
                      <p className="text-xs font-semibold text-slate-500">
                        Reported Summary ({selectedReport.aiSummary.incidentCategory})
                      </p>
                      <p className="text-sm text-slate-900 mt-1 leading-relaxed">
                        {selectedReport.aiSummary.reportedFactsSummary}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="bg-white border border-slate-200 rounded-xl p-3">
                        <span className="text-slate-500">Frequency</span>
                        <p className="font-medium text-slate-900 mt-0.5">
                          {selectedReport.frequency}
                        </p>
                      </div>
                      <div className="bg-white border border-slate-200 rounded-xl p-3">
                        <span className="text-slate-500">Locations</span>
                        <p className="font-medium text-slate-900 mt-0.5">
                          {selectedReport.locations.join(', ')}
                        </p>
                      </div>
                      <div className="bg-white border border-slate-200 rounded-xl p-3">
                        <span className="text-slate-500">Emotions Expressed</span>
                        <p className="font-medium text-slate-900 mt-0.5">
                          {selectedReport.feelings.join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="bg-indigo-50/60 border border-indigo-200 rounded-xl p-4">
                      <p className="text-xs font-semibold text-indigo-950">
                        How to Support Your Child (Recommended Next Steps)
                      </p>
                      <p className="text-sm text-slate-800 mt-1 leading-relaxed">
                        {selectedReport.aiSummary.recommendedNextSteps}
                      </p>
                      <p className="text-xs text-slate-500 mt-2">
                        {selectedReport.aiSummary.disclaimer}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {notifications.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-2xl p-6">
              <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2">
                <Mail className="w-4 h-4 text-indigo-600" />
                Safeguarding Email Dispatch Log
              </h3>
              <div className="mt-3 divide-y divide-slate-200">
                {notifications.map((n) => (
                  <div key={n.id} className="py-3 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-slate-900">{n.subject}</span>
                      <span className="font-mono text-slate-500">{n.deliveryStatus}</span>
                    </div>
                    <p className="text-slate-600 mt-1 whitespace-pre-line">{n.summaryPreview}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
