import { useState } from 'react';
import { ArrowRight, CheckCircle2, HelpCircle } from 'lucide-react';
import type { AppView } from '../types/udaan';
import { ResilientImage } from './ResilientImage';

const LEARNING_TOPICS = [
  {
    id: 'what-is-bullying',
    title: '01. What Is Bullying?',
    summary:
      'Bullying is when someone hurts, scares, leaves out, or embarrasses another person on purpose—and often does it repeatedly when one person has more power or feels harder to stop.',
    points: [
      'Physical: pushing, hitting, tripping, or damaging someone’s bag or books.',
      'Verbal: hurtful teasing, threats, name-calling, or mocking.',
      'Social: leaving someone out on purpose, spreading rumours, or telling others not to be friends with them.',
    ],
  },
  {
    id: 'what-is-cyberbullying',
    title: '02. What Is Cyberbullying?',
    summary:
      'Cyberbullying is bullying using phones, games, social apps, or group chats. Even though it happens on a screen, the hurt is just as real.',
    points: [
      'Sending mean messages, comments, or threats in class chats or games.',
      'Sharing embarrassing photos or rumours without permission.',
      'Creating fake accounts or excluding someone from online school groups.',
    ],
  },
  {
    id: 'recognise-bullying',
    title: '03. How to Recognise Bullying',
    summary:
      'Sometimes it can be confusing to tell the difference between an argument and bullying. Ask yourself three simple questions:',
    points: [
      'Was it done on purpose to hurt or upset someone?',
      'Does it keep happening, or threaten to happen again?',
      'Does the person being targeted feel powerless, scared, or unsafe?',
    ],
  },
  {
    id: 'what-to-do',
    title: '04. What to Do When Someone Bullies You',
    summary:
      'If someone bullies you, it is never your fault. You deserve support right away.',
    points: [
      'Move near a teacher, bus driver, parent, or safe group of friends.',
      'For online bullying: do not reply—take screenshots, block the sender, and show a trusted adult.',
      'Tell a parent, teacher, or use UDAAN’s “I Need Help” form so an adult can step in safely.',
    ],
  },
  {
    id: 'support-friend',
    title: '05. How to Support a Friend',
    summary:
      'Kindness from even one classmate makes a huge difference when someone feels alone.',
    points: [
      'Sit with them at lunch, walk with them between classes, or invite them into your group.',
      'Listen calmly without judging and say: “I’m glad you told me—you don’t have to handle this alone.”',
      'Offer to go with them to talk to a teacher or school counselor.',
    ],
  },
  {
    id: 'reporting-not-wrong',
    title: '06. Why Reporting Bullying Is Not Wrong',
    summary:
      'Many kids worry about “tattling.” Reporting bullying is completely different from tattling.',
    points: [
      'Tattling is trying to get someone into trouble over a small, harmless mistake.',
      'Reporting is asking a trusted adult for help because someone is getting hurt, scared, or treated unfairly.',
      'Speaking up helps protect both you and other students at your school.',
    ],
  },
  {
    id: 'responsible-bystander',
    title: '07. How to Be a Responsible Bystander (Upstander)',
    summary:
      'You do not have to confront anyone aggressively to make a positive difference.',
    points: [
      'Change the subject or help the targeted student walk away safely.',
      'Never forward, laugh at, or “like” hurtful posts or rumours.',
      'Quietly report what you saw to a trusted teacher or through UDAAN.',
    ],
  },
];

const SCENARIOS = [
  {
    question:
      'Every Tuesday on the school bus, an older student hides Maya’s backpack and laughs when she asks for it back. Maya dreads riding the bus. What should happen?',
    options: [
      {
        label: 'Ignore it completely because telling an adult is tattling.',
        correct: false,
        feedback:
          'Asking for help when someone is repeatedly taking your belongings or making you feel unsafe is reporting, not tattling.',
      },
      {
        label: 'Sit near the bus driver or a friend, and tell a parent or school counselor.',
        correct: true,
        feedback:
          'Correct. Moving closer to a trusted adult and reporting repeated behaviour keeps Maya safe without escalating confrontation.',
      },
    ],
  },
  {
    question:
      'Someone posts an unkind edited photo of your classmate in a group chat. Several people start laughing in the replies. How can you be an Upstander?',
    options: [
      {
        label: 'Save a screenshot for an adult, do not share it, check in privately with your classmate, and tell a trusted adult.',
        correct: true,
        feedback:
          'Exactly right. Refusing to spread hurtful content, supporting your classmate privately, and alerting an adult protects everyone.',
      },
      {
        label: 'Forward it to other friends to warn them.',
        correct: false,
        feedback:
          'Forwarding hurtful images spreads the harm further. Take evidence to an adult instead of sharing it with peers.',
      },
    ],
  },
];

export function LearningCentre({ onNavigate }: { onNavigate: (view: AppView) => void }) {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header */}
      <div className="max-w-3xl">
        <p className="text-xs font-medium text-indigo-700">
          UDAAN Learning Centre · Student &amp; Peer Safety Guide
        </p>
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mt-1 text-balance">
          Understanding Bullying, Online Safety &amp; Standing Together
        </h1>
        <p className="text-base text-slate-600 mt-3 leading-relaxed">
          Clear, simple guides to help you recognise unkind behaviour, know your rights, and support
          friends safely.
        </p>
      </div>

      {/* Illustrated Spotlight Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col">
          <ResilientImage
            src="/src/assets/images/learn_recognise_bullying_1795013475293.jpg"
            alt="A student talking calmly on a school bench with a caring school counselor"
            fallbackTitle="Talk to a Trusted Adult"
            className="w-full h-52 object-cover"
          />
          <div className="p-5">
            <h2 className="text-base font-semibold text-slate-900">Speaking Up Is Brave</h2>
            <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
              Counselors, teachers, and parents are there to listen without judgement when
              something makes you feel unsafe.
            </p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col">
          <ResilientImage
            src="/src/assets/images/learn_cyberbullying_safety_1795013475651.jpg"
            alt="A student closing a tablet and having a reassuring conversation with a parent"
            fallbackTitle="Online & Screen Safety"
            className="w-full h-52 object-cover"
          />
          <div className="p-5">
            <h2 className="text-base font-semibold text-slate-900">Pause, Save &amp; Share</h2>
            <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
              When hurtful messages appear online, step away from the screen, save proof, and show
              a trusted adult right away.
            </p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col">
          <ResilientImage
            src="/src/assets/images/learn_upstander_support_1795013477004.jpg"
            alt="A friendly classmate welcoming another student to a library table"
            fallbackTitle="Be a Supportive Friend"
            className="w-full h-52 object-cover"
          />
          <div className="p-5">
            <h2 className="text-base font-semibold text-slate-900">Inclusion Changes Everything</h2>
            <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
              Inviting someone to sit with you or walking alongside them helps take away the power
              of exclusion.
            </p>
          </div>
        </div>
      </div>

      {/* 7 Structured Educational Modules */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {LEARNING_TOPICS.map((topic) => (
          <article
            key={topic.id}
            className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3"
          >
            <h2 className="text-lg font-semibold text-slate-900">{topic.title}</h2>
            <p className="text-sm text-slate-700 leading-relaxed">{topic.summary}</p>
            <ul className="space-y-2 pt-1">
              {topic.points.map((point) => (
                <li key={point} className="text-sm text-slate-600 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600 mt-0.5 shrink-0" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>

      {/* Interactive Scenario Check */}
      <section className="bg-blue-50/60 border border-blue-200 rounded-2xl p-6 sm:p-8 space-y-6">
        <div className="flex items-start gap-3">
          <HelpCircle className="w-6 h-6 text-indigo-600 shrink-0 mt-0.5" />
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Practice Safe Choices: Quick Scenarios
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Tap an answer to see how responsible bystanders and students handle real situations.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {SCENARIOS.map((sc, sIdx) => {
            const chosenIdx = selectedAnswers[sIdx];
            return (
              <div key={sc.question} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                <p className="text-sm font-semibold text-slate-900 leading-relaxed">
                  {sc.question}
                </p>
                <div className="space-y-2">
                  {sc.options.map((opt, oIdx) => {
                    const isPicked = chosenIdx === oIdx;
                    return (
                      <button
                        key={opt.label}
                        type="button"
                        onClick={() =>
                          setSelectedAnswers((prev) => ({ ...prev, [sIdx]: oIdx }))
                        }
                        className={`w-full text-left px-4 py-3 rounded-xl border text-xs sm:text-sm transition-colors cursor-pointer ${
                          isPicked
                            ? opt.correct
                              ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-medium'
                              : 'bg-amber-50 border-amber-400 text-amber-950'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
                {chosenIdx !== undefined && (
                  <p className="text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-xl p-3">
                    {sc.options[chosenIdx].feedback}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
          <p className="text-sm font-medium text-indigo-950">
            Need help for yourself or a friend right now?
          </p>
          <button
            type="button"
            onClick={() => onNavigate('report')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold cursor-pointer"
          >
            Open Help Questionnaire
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>
    </div>
  );
}
