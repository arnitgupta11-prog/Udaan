import { useEffect, useState } from 'react';
import { deleteDoc, doc } from 'firebase/firestore';
import { CheckCircle2, Lock, Server, ShieldCheck, Trash2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { EmergencySupportPanel } from './EmergencySupportPanel';

interface HealthStatus {
  ok: boolean;
  geminiConfigured: boolean;
  smtpConfigured: boolean;
  appUrlConfigured: boolean;
}

export function PrivacyAndSetup() {
  const { user, parentProfile, studentProfile, refreshProfiles } = useAuth();
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [deleteFeedback, setDeleteFeedback] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/health')
      .then(async (res) => {
        const text = await res.text();
        if (!res.ok) return null;
        return JSON.parse(text) as HealthStatus;
      })
      .then((data) => {
        if (data) setHealth(data);
      })
      .catch(() => setHealth(null));
  }, []);

  const handleDeleteProfileData = async () => {
    if (!user) return;
    setDeleteFeedback(null);
    try {
      if (parentProfile) {
        await deleteDoc(doc(db, 'parents', user.uid));
      }
      if (studentProfile) {
        await deleteDoc(doc(db, 'students', user.uid));
      }
      await refreshProfiles();
      setDeleteConfirm(false);
      setDeleteFeedback(
        'Your personal parent/student profile record has been deleted. Safeguarding case logs required for child safety are governed by school retention policy.',
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `profiles/${user.uid}`);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div>
        <p className="text-xs font-medium text-indigo-700">
          Privacy, Safeguarding Governance &amp; System Setup
        </p>
        <h1 className="text-3xl font-bold text-slate-900 mt-1">
          Child Safety, Privacy Controls &amp; Architecture
        </h1>
        <p className="text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
          UDAAN is engineered around data minimisation, role-based access enforcement, honest
          confidentiality boundaries, and auditable safeguarding workflows.
        </p>
      </div>

      {/* Child-Friendly Privacy & Confidentiality Commitments */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3">
          <div className="flex items-center gap-2 text-indigo-700 font-semibold text-base">
            <ShieldCheck className="w-5 h-5" />
            Age-Appropriate Privacy Promise
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            We only ask what is needed to help you stay safe: what happened, how often, where,
            how you feel, and whether you are safe right now. We never display ads, track students
            across websites, or sell personal information.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3">
          <div className="flex items-center gap-2 text-indigo-700 font-semibold text-base">
            <Lock className="w-5 h-5" />
            Confidentiality Limitations (No False Promises)
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            UDAAN never promises absolute secrecy. If a child reports harm, threats, or feeling
            unsafe, trusted safeguarding personnel must be able to step in and protect them. Other
            students can never access anyone else’s reports.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3">
          <h2 className="text-base font-semibold text-slate-900">
            Data Retention &amp; Deletion Policy
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Personal student and parent profile preferences can be updated or removed by the
            verified account holder at any time. Active safeguarding case records and audit trails
            are retained strictly under school child-protection rules and automatically archived
            after resolution.
          </p>

          {user && (parentProfile || studentProfile) && (
            <div className="pt-2">
              {!deleteConfirm ? (
                <button
                  type="button"
                  onClick={() => setDeleteConfirm(true)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-700 hover:text-rose-800 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete my saved Parent/Student profile record
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => void handleDeleteProfileData()}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-semibold cursor-pointer"
                  >
                    Confirm Profile Deletion
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteConfirm(false)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-600 cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              )}
              {deleteFeedback && (
                <p className="text-xs text-emerald-800 mt-2">{deleteFeedback}</p>
              )}
            </div>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3">
          <div className="flex items-center gap-2 text-indigo-700 font-semibold text-base">
            <Server className="w-5 h-5" />
            Backend Integration &amp; Setup Status
          </div>
          <ul className="space-y-2 text-xs text-slate-700">
            <li className="flex items-center justify-between py-1.5 border-b border-slate-100">
              <span>Firebase Authentication &amp; Cloud Firestore Rules</span>
              <span className="font-semibold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Active
              </span>
            </li>
            <li className="flex items-center justify-between py-1.5 border-b border-slate-100">
              <span>Direct Checklist Submission</span>
              <span className="font-semibold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Active
              </span>
            </li>
            <li className="flex items-center justify-between py-1.5">
              <span>SMTP Parent Email Delivery</span>
              <span
                className={`font-semibold ${
                  health?.smtpConfigured ? 'text-emerald-700' : 'text-slate-700'
                }`}
              >
                {health
                  ? health.smtpConfigured
                    ? 'Live SMTP Active'
                    : 'In-App Audit Dispatch (Add SMTP_* env vars for live mail)'
                  : 'Checking...'}
              </span>
            </li>
          </ul>
          <p className="text-xs text-slate-500 leading-relaxed">
            To enable live external email delivery in production, configure{' '}
            <code className="font-mono text-slate-700">
              SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
            </code>{' '}
            in your server environment variables (documented in <code className="font-mono">.env.example</code>).
          </p>
        </div>
      </div>

      <EmergencySupportPanel />
    </div>
  );
}
