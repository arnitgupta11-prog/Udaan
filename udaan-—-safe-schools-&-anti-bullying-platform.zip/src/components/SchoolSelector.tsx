import { DEFAULT_SCHOOLS } from '../types/udaan';

interface SchoolSelectorProps {
  label?: string;
  selectedSchoolId: string;
  customSchoolName: string;
  onSelectSchoolId: (schoolId: string) => void;
  onChangeCustomSchoolName: (name: string) => void;
  compact?: boolean;
}

export function SchoolSelector({
  label = 'School Name',
  selectedSchoolId,
  customSchoolName,
  onSelectSchoolId,
  onChangeCustomSchoolName,
  compact = false,
}: SchoolSelectorProps) {
  const isCustom = selectedSchoolId === 'custom';

  return (
    <div className="space-y-2">
      <label className="block text-xs font-semibold text-slate-700">{label}</label>
      <select
        value={selectedSchoolId}
        onChange={(e) => onSelectSchoolId(e.target.value)}
        className={`w-full rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-600 ${
          compact ? 'px-3 py-2 text-xs' : 'px-3.5 py-2.5 text-sm'
        }`}
      >
        {DEFAULT_SCHOOLS.map((s) => (
          <option key={s.id} value={s.id}>
            {s.name}
          </option>
        ))}
        <option value="custom">Other (Type school name)</option>
      </select>

      {isCustom && (
        <input
          type="text"
          required
          maxLength={160}
          value={customSchoolName}
          onChange={(e) => onChangeCustomSchoolName(e.target.value)}
          placeholder="Type your school's full name..."
          aria-label="Custom school name"
          className={`w-full rounded-xl border border-indigo-300 bg-white text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600 ${
            compact ? 'px-3 py-2 text-xs' : 'px-3.5 py-2.5 text-sm'
          }`}
        />
      )}
    </div>
  );
}
