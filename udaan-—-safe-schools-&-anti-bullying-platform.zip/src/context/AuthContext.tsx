import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from '../firebase';
import {
  BOOTSTRAPPED_ADMIN_EMAIL,
  DEFAULT_SCHOOLS,
  type ParentProfile,
  type SchoolStaffRecord,
  type StudentProfile,
  type UserProfile,
} from '../types/udaan';

interface AuthContextValue {
  user: User | null;
  authReady: boolean;
  userProfile: UserProfile | null;
  parentProfile: ParentProfile | null;
  studentProfile: StudentProfile | null;
  staffProfile: SchoolStaffRecord | null;
  isAdmin: boolean;
  isAuthorizedStaff: boolean;
  authError: string | null;
  signInWithGoogle: () => Promise<User | null>;
  logout: () => Promise<void>;
  refreshProfiles: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [parentProfile, setParentProfile] = useState<ParentProfile | null>(null);
  const [studentProfile, setStudentProfile] = useState<StudentProfile | null>(null);
  const [staffProfile, setStaffProfile] = useState<SchoolStaffRecord | null>(null);
  const [isAdminDoc, setIsAdminDoc] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const loadProfiles = async (currentUser: User) => {
    const uid = currentUser.uid;
    const isBootAdmin =
      currentUser.emailVerified &&
      currentUser.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase();

    try {
      const userRef = doc(db, 'users', uid);
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        setUserProfile(userSnap.data() as UserProfile);
      } else if (currentUser.emailVerified && currentUser.email) {
        const defaultSchool = DEFAULT_SCHOOLS[0];
        const initialProfile = {
          uid,
          email: currentUser.email,
          displayName: (currentUser.displayName || 'UDAAN Member').slice(0, 120),
          role: isBootAdmin ? 'admin' : 'student',
          schoolId: defaultSchool.id,
          schoolName: defaultSchool.name,
          emailVerified: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        await setDoc(userRef, initialProfile);
        const createdSnap = await getDoc(userRef);
        if (createdSnap.exists()) {
          setUserProfile(createdSnap.data() as UserProfile);
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `users/${uid}`);
    }

    try {
      const parentSnap = await getDoc(doc(db, 'parents', uid));
      setParentProfile(parentSnap.exists() ? (parentSnap.data() as ParentProfile) : null);
    } catch {
      setParentProfile(null);
    }

    try {
      const studentSnap = await getDoc(doc(db, 'students', uid));
      setStudentProfile(studentSnap.exists() ? (studentSnap.data() as StudentProfile) : null);
    } catch {
      setStudentProfile(null);
    }

    try {
      const staffSnap = await getDoc(doc(db, 'school_staff', uid));
      setStaffProfile(staffSnap.exists() ? (staffSnap.data() as SchoolStaffRecord) : null);
    } catch {
      setStaffProfile(null);
    }

    try {
      const adminSnap = await getDoc(doc(db, 'admins', uid));
      setIsAdminDoc(adminSnap.exists());
    } catch {
      setIsAdminDoc(false);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      setAuthError(null);
      if (nextUser) {
        try {
          await loadProfiles(nextUser);
        } catch (err) {
          setAuthError(err instanceof Error ? err.message : 'Unable to load account profile.');
        }
      } else {
        setUserProfile(null);
        setParentProfile(null);
        setStudentProfile(null);
        setStaffProfile(null);
        setIsAdminDoc(false);
      }
      setAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async (): Promise<User | null> => {
    setAuthError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        await loadProfiles(result.user);
      }
      return result.user;
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google sign-in could not be completed.';
      setAuthError(msg);
      return null;
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  const refreshProfiles = async () => {
    if (auth.currentUser) {
      await loadProfiles(auth.currentUser);
    }
  };

  const isAdmin = Boolean(
    user?.emailVerified &&
      (user.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase() || isAdminDoc),
  );

  const isAuthorizedStaff = Boolean(
    isAdmin || (user?.emailVerified && staffProfile?.authorized),
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        authReady,
        userProfile,
        parentProfile,
        studentProfile,
        staffProfile,
        isAdmin,
        isAuthorizedStaff,
        authError,
        signInWithGoogle,
        logout,
        refreshProfiles,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
