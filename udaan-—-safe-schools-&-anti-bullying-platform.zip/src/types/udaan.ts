import type { Timestamp } from 'firebase/firestore';

export type AppView = 'home' | 'report' | 'learn' | 'parent' | 'dashboard' | 'privacy';

export type UserRole = 'student' | 'parent' | 'staff' | 'admin';

export type ReportStatus = 'awaiting_review' | 'under_review' | 'resolved';

export type SafeRightNowOption = 'yes' | 'no' | 'unsure';

export type TrustedAdultChannel = 'parent' | 'school_counselor' | 'both';

export interface AiReportSummary {
  incidentCategory: string;
  reportedFactsSummary: string;
  frequency: string;
  reportedLocation: string;
  emotionalImpact: string;
  immediateSafetyConcern: boolean;
  recommendedNextSteps: string;
  disclaimer: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  schoolId: string;
  schoolName: string;
  emailVerified: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ParentProfile {
  parentUid: string;
  name: string;
  email: string;
  emailVerified: boolean;
  childName: string;
  studentCode: string;
  schoolId: string;
  schoolName: string;
  notifyOnSubmit: boolean;
  notifyUrgentOnly: boolean;
  consentConfirmed: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface StudentProfile {
  studentUid: string;
  displayName: string;
  studentCode: string;
  schoolId: string;
  schoolName: string;
  parentUid?: string;
  parentEmail?: string;
  trustedAdultOption: TrustedAdultChannel;
  consentConfirmed: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface BullyingReport {
  id?: string;
  referenceCode: string;
  reporterUid: string;
  studentName: string;
  studentCode: string;
  schoolId: string;
  schoolName: string;
  parentUid?: string;
  parentEmail?: string;
  parentSafeToNotify: boolean;
  trustedAdultChannel: TrustedAdultChannel;
  incidents: string[];
  frequency: 'Once' | 'A few times' | 'Every week' | 'Almost every day';
  locations: string[];
  feelings: string[];
  isSafeRightNow: SafeRightNowOption;
  additionalInfo: string;
  urgentFlag: boolean;
  status: ReportStatus;
  staffAccessUids: string[];
  aiSummary: AiReportSummary;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface SchoolStaffRecord {
  uid: string;
  email: string;
  name: string;
  staffRole: 'counselor' | 'safeguarding_lead' | 'principal';
  schoolId: string;
  schoolName: string;
  authorized: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface NotificationRecord {
  id?: string;
  reportId: string;
  referenceCode: string;
  actorUid: string;
  recipientUid?: string;
  recipientEmail: string;
  recipientType: 'parent' | 'school_staff';
  schoolId: string;
  subject: string;
  summaryPreview: string;
  deliveryStatus:
    | 'sent_smtp'
    | 'logged_awaiting_smtp'
    | 'blocked_unverified_email'
    | 'suppressed_child_safety';
  safeguardingCheckPassed: boolean;
  createdAt?: Timestamp;
}

export interface FollowUpNote {
  id?: string;
  reportId: string;
  schoolId: string;
  authorUid: string;
  authorName: string;
  actionTaken: string;
  note: string;
  statusAfter: ReportStatus;
  staffAccessUids?: string[];
  createdAt?: Timestamp;
}

export interface AuditLogEntry {
  id?: string;
  reportId?: string;
  schoolId: string;
  actorUid: string;
  actorEmail: string;
  actorRole: UserRole;
  action:
    | 'submitted_report'
    | 'viewed_report'
    | 'updated_status'
    | 'added_followup'
    | 'dispatched_notification'
    | 'updated_parent_email';
  createdAt?: Timestamp;
}

export const DEFAULT_SCHOOLS = [
  { id: 'oakwood-middle', name: 'Oakwood Middle School' },
  { id: 'dps-noida', name: 'Delhi Public School Noida' },
  { id: 'sunrise-academy', name: 'Sunrise Public Academy' },
  { id: 'horizon-high', name: 'Horizon International School' },
] as const;

export const BOOTSTRAPPED_ADMIN_EMAIL = '2018008arnit@dpsnoida.co.in';

export function slugifySchoolName(name: string): string {
  const slug = name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return slug || 'custom-school';
}
