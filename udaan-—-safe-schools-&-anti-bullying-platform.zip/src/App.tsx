import { useEffect, useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { ChildReportFlow } from './components/ChildReportFlow';
import { LearningCentre } from './components/LearningCentre';
import { ParentPortal } from './components/ParentPortal';
import { SchoolDashboard } from './components/SchoolDashboard';
import { PrivacyAndSetup } from './components/PrivacyAndSetup';
import type { AppView } from './types/udaan';

function UdaanAppContent() {
  const [currentView, setCurrentView] = useState<AppView>('home');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const portal = params.get('portal');
    if (portal === 'parent') setCurrentView('parent');
    else if (portal === 'dashboard') setCurrentView('dashboard');
    else if (portal === 'report') setCurrentView('report');
    else if (portal === 'learn') setCurrentView('learn');
    else if (portal === 'privacy') setCurrentView('privacy');
  }, []);

  const handleNavigate = (view: AppView) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900">
      <Navbar currentView={currentView} onNavigate={handleNavigate} />

      <main className="flex-1">
        {currentView === 'home' && <LandingPage onNavigate={handleNavigate} />}
        {currentView === 'report' && <ChildReportFlow onNavigate={handleNavigate} />}
        {currentView === 'learn' && <LearningCentre onNavigate={handleNavigate} />}
        {currentView === 'parent' && <ParentPortal />}
        {currentView === 'dashboard' && <SchoolDashboard />}
        {currentView === 'privacy' && <PrivacyAndSetup />}
      </main>

      <footer className="bg-white border-t border-slate-200/80 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800 font-display">UDAAN</span>
            <span aria-hidden="true">·</span>
            <span>Every Child Deserves to Feel Safe, Heard and Respected.</span>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            <button
              type="button"
              onClick={() => handleNavigate('report')}
              className="hover:text-slate-900 cursor-pointer"
            >
              I Need Help
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('learn')}
              className="hover:text-slate-900 cursor-pointer"
            >
              Learning Centre
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('parent')}
              className="hover:text-slate-900 cursor-pointer"
            >
              Parent Portal
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('privacy')}
              className="hover:text-slate-900 cursor-pointer"
            >
              Privacy &amp; Safety
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <UdaanAppContent />
      </AuthProvider>
    </ErrorBoundary>
  );
}
